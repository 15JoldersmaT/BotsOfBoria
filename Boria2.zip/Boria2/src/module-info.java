/**
 * 
 */
/**
 * 
 */
module Boria2 {
	requires java.desktop;
}