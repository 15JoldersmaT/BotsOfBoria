package pack;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Boria extends JPanel implements ActionListener {
    private Timer timer;
    public static List<Bot> bots;
    public static List<Tile> tiles;

    private final int DELAY = 35; // Milliseconds between update/render calls
    public static Universe u = new Universe();
    
    public static boolean big = false;
    public static boolean little = false;
    public static boolean col = false;
    public static boolean gravity = false;
    public static int sTime = 30;
    public Boria() {
        setPreferredSize(new Dimension(1300, 800));
        setBackground(Color.BLACK);
        initGame();
    }

    private void initGame() {
        bots = new ArrayList<>();
        // Populate the bots list
        for (int i = 0; i < 2500; i++) { // Example: creating 100 bots
            bots.add(new Bot(650, 400, new Color(255,0,0))); // Starting all bots at the center for simplicity
        }
        
        int tx = 0, ty = 0;
        int startX = 0, startY = 0;
        for (int i = 0; i < 225;i++) {
        	tx = startX * 100;
        	ty = startY * 100;
        	startX = startX + 1;
        	if (startX > 15) {
        		startY = startY + 1;
        		startX = 0;
        	}
        	try {
        	tiles.add(new Tile(tx,ty));
        	}catch(Exception e) {
        		
        	}
        }
        timer = new Timer(DELAY, this);
        timer.start();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        doDrawing(g);
    }

    private void doDrawing(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        for (Bot bot : bots) {
            bot.draw(g2d);
        }
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        updateGame();
        repaint();
    }

    private void updateGame() {
        // Assume you have an ExecutorService
        ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

        // Submit bot update tasks to the executor
        for (Bot bot : bots) {
            executor.submit(() -> {
                bot.update();
            });
        }
        try {
        for (Tile tile : tiles) {
            executor.submit(() -> {
                tile.update();
            });
        }
        }
        catch(Exception e) {
        	
        }
        // Shutdown the executor and wait for all tasks to finish before proceeding
        executor.shutdown();
        try {
            if (!executor.awaitTermination(800, TimeUnit.MILLISECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
        }

        // Since bots are updated, proceed with repainting in the EDT
        SwingUtilities.invokeLater(this::repaint);
    }

    public static void main(String[] args) {
    	SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Bots of Boria");
            Boria simulation = new Boria();
            
            frame.add(simulation);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);

            frame.addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                	
                	if (e.getKeyCode() == KeyEvent.VK_Q) { // If 'R' key is pressed
                        sTime = 10;
                    }
                	if (e.getKeyCode() == KeyEvent.VK_W) { // If 'R' key is pressed
                        sTime = 60;
                    }
                	if (e.getKeyCode() == KeyEvent.VK_E) { // If 'R' key is pressed
                        sTime = 1000;
                    }
                    if (e.getKeyCode() == KeyEvent.VK_R) { // If 'R' key is pressed
                        u.reset();; // Call the static resetGame method
                        simulation.repaint(); // Repaint the simulation panel to reflect changes
                    }
                    
                    if (e.getKeyCode() == KeyEvent.VK_G) { 
                        if(gravity == true) {
                        	gravity = false;
                        }else {
                        	gravity = true;
                        }
                    }
                    
                    if (e.getKeyCode() == KeyEvent.VK_B) { 
                       if (big == true) {
                    	   big =false;
                       }else {
                    	   big =true;
                       }
                    	   
                    }
                    if (e.getKeyCode() == KeyEvent.VK_C) { 
                        if (col == true) {
                     	   col =false;
                        }else {
                     	   col =true;
                        }
                     	   
                     }
                    if (e.getKeyCode() == KeyEvent.VK_L) { 
                        if (little == true) {
                        	little =false;
                        }else {
                        	little =true;
                        }
                     	   
                     }
                }
            });
            try {
				Thread.sleep(sTime);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

            frame.setFocusable(true);
            frame.requestFocusInWindow();
        });
        
        
    }
}

