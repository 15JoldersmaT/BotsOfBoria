package pack;

import java.util.List;

public class Tile {
	private List<Bot> bots;
	private int x,y;
	private int g;
	
	public Tile(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	
	public void update() {
		int botCount = 0;
		double newG = 0;
		for (int i = 0;i<Boria.bots.size();i++) {
			if (Boria.bots.get(i).getX() >= this.x && Boria.bots.get(i).getY() >= this.y && Boria.bots.get(i).getX() < this.x + 100 && Boria.bots.get(i).getY() < this.y + 100) {
				bots.add(Boria.bots.get(i));
				Boria.bots.get(i).setTile(this);
			}
			else {
				bots.remove(Boria.bots.get(i));
			}
			System.out.println("Test");
		}
	}
	public List<Bot> getBots() {
		return bots;
	}

	public void setBots(List<Bot> bots) {
		this.bots = bots;
	}

	public int getG() {
		return g;
	}

	public void setG(int g) {
		this.g = g;
	}
	
	public int getX() {
		return this.x;
	}
	
	public int getY() {
		return this.y;
	}
}
