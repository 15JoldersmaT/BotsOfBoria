package pack;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Boria extends JPanel implements ActionListener {
    private Timer timer;
    public static List<Bot> bots;
    public static List<Tile> tiles;

    private  static int DELAY = 15; // Milliseconds between update/render calls
    public static Universe u = new Universe();
    
    public static boolean big = false;
    public static boolean little = false;
    public static boolean reallyLittle = false;
    public static boolean kMode = false;
    public static boolean dMode = false;
    public static boolean nMode = false;
    public static boolean sMode = false;

    public static boolean uMode = false;

    
    public static boolean high = false;
    public static boolean gravityM = false ;

    public static boolean col = false;
    
    public static boolean auto = false;
    public static int countDown = 1000;
    public static boolean emptyMode = false;
    public static Random rand = new Random();

    public static boolean gravity = false;
    public static boolean gravityC = false;

    public static int sTime = 1;
    public Boria() {
        setPreferredSize(new Dimension(1300, 800));
        setBackground(Color.BLACK);
        initGame();
    }

    private void initGame() {
        bots = new ArrayList<>();
        // Populate the bots list
        for (int i = 0; i < 2500; i++) { // Example: creating 100 bots
            bots.add(new Bot(650, 400, new Color(255,0,0))); // Starting all bots at the center for simplicity
        }
        
        int tx = 0, ty = 0;
        int startX = 0, startY = 0;
        for (int i = 0; i < 225;i++) {
        	tx = startX * 100;
        	ty = startY * 100;
        	startX = startX + 1;
        	if (startX > 15) {
        		startY = startY + 1;
        		startX = 0;
        	}
        	try {
        	tiles.add(new Tile(tx,ty));
        	}catch(Exception e) {
        		
        	}
        }
        timer = new Timer(DELAY, this);
        timer.start();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        doDrawing(g);
    }

    private void doDrawing(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        for (Bot bot : bots) {
            bot.draw(g2d);
        }
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        updateGame();
        repaint();
    }

    private void updateGame() {
        // Assume you have an ExecutorService
        ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
        countDown = countDown - 1;
        if (auto == true) {
			System.out.println(countDown);

			if (countDown < 1) {
				countDown = 500;
    			int sChance = rand.nextInt(5);
    			int gChance = rand.nextInt(6);
    			int cChance = rand.nextInt(5);
    			int dChance = rand.nextInt(5);
    			
    			if (dChance <= 2) {
    				little = true;
    			}
    			if (dChance >= 3) {
    				little = false;
    			}
    			if (dChance >= 4) {
    				little = false;
    				big = true;
    			}
    			
    			if (sChance <= 2) {
    				high = true;
    			}
    			if (sChance >= 3) {
    				high = false;
    			}
    			if (gChance >= 3) {
    				gravity = false;
    			}else {
    				gravity = true;
    			}
    			if (gChance >= 5) {
    				gravityC = false;
    			}else {
    				gravityC = true;
    			}
    			if (cChance <= 3) {
    				col = false;
    			}else {
    				col = true;
    			}
				u.reset();; // Call the static resetGame method
			}
        }
        // Submit bot update tasks to the executor
        for (Bot bot : bots) {
            executor.submit(() -> {
                bot.update();
            });
        }
        try {
        for (Tile tile : tiles) {
            executor.submit(() -> {
                tile.update();
            });
        }
        }
        catch(Exception e) {
        	
        }
        // Shutdown the executor and wait for all tasks to finish before proceeding
        executor.shutdown();
        try {
            if (!executor.awaitTermination(800, TimeUnit.MILLISECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
        }

        // Since bots are updated, proceed with repainting in the EDT
        SwingUtilities.invokeLater(this::repaint);
    
    }

    public static void main(String[] args) {
    	SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Bots of Boria");
            Boria simulation = new Boria();
            
            frame.add(simulation);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);

            frame.addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                	
                	if (e.getKeyCode() == KeyEvent.VK_H) { // If 'R' key is pressed
                		if(high == true) {
                			high = false;
                        }else {
                        	high = true;
                        	System.out.println("high");
                        }
                    }
                	if (e.getKeyCode() == KeyEvent.VK_W) { // If 'R' key is pressed
                		DELAY = 60;
                    }
                	if (e.getKeyCode() == KeyEvent.VK_E) { // If 'R' key is pressed
                		if(emptyMode == true) {
                			emptyMode = false;
                        }else {
                        	emptyMode = true;
                        }
                    }
                    if (e.getKeyCode() == KeyEvent.VK_R) { // If 'R' key is pressed
                        u.reset();; // Call the static resetGame method
                        simulation.repaint(); // Repaint the simulation panel to reflect changes
                    }
                    
                    if (e.getKeyCode() == KeyEvent.VK_G) { 
                        if(gravity == true) {
                        	gravity = false;
                        }else {
                        	gravity = true;
                        }
                    }
                    if (e.getKeyCode() == KeyEvent.VK_M) { 
                        if(gravityM == true) {
                        	gravityM = false;
                        }else {
                        	gravityM = true;
                        }
                    }
                    if (e.getKeyCode() == KeyEvent.VK_N) { 
                        if(nMode == true) {
                        	nMode = false;
                        }else {
                        	nMode = true;
                        }
                    }
                    if (e.getKeyCode() == KeyEvent.VK_U) { 
                        if(uMode == true) {
                        	uMode = false;
                        }else {
                        	uMode = true;
                        }
                    }
                    if (e.getKeyCode() == KeyEvent.VK_S) { 
                        if(sMode == true) {
                        	sMode = false;
                        }else {
                        	sMode = true;
                        }
                    }
                    if (e.getKeyCode() == KeyEvent.VK_F) { 
                        if(gravityC == true) {
                        	gravityC = false;
                        }else {
                        	gravityC = true;
                        }
                    }
                    
                    if (e.getKeyCode() == KeyEvent.VK_B) { 
                       if (big == true) {
                    	   big =false;
                       }else {
                    	   big =true;
                       }
                    	   
                    }
                    
                    if (e.getKeyCode() == KeyEvent.VK_D) { 
                        if (dMode == true) {
                     	   dMode =false;
                        }else {
                     	   dMode =true;
                        }
                     	   
                     }
                    
                    if (e.getKeyCode() == KeyEvent.VK_A) { 
                        if (auto == true) {
                     	   auto =false;
                        }else {
        				   System.out.println(countDown);

                     	   auto =true;
                        }
                     	   
                     }
                    if (e.getKeyCode() == KeyEvent.VK_C) { 
                        if (col == true) {
                     	   col =false;
                     	   
                        }else {
                     	   col =true;
                        }
                        u.reset();; // Call the static resetGame method
                        simulation.repaint(); // Repaint the simulation panel to reflect changes
                     	   
                     }
                    if (e.getKeyCode() == KeyEvent.VK_L) { 
                        if (little == true) {
                        	little =false;
                        }else {
                        	little =true;
                        }
                     	 
                        
                     }
                    if (e.getKeyCode() == KeyEvent.VK_K) { 
                        if (kMode == true) {
                        	kMode =false;
                        }else {
                        	kMode =true;
                        }
                     	 
                        
                     }
                    if (e.getKeyCode() == KeyEvent.VK_Q) { 
                        if (reallyLittle == true) {
                        	reallyLittle =false;
                        }else {
                        	reallyLittle =true;
                        }
                     	 
                        
                     }
                }
            });
            try {
				Thread.sleep(sTime);

				
				
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

            frame.setFocusable(true);
            frame.requestFocusInWindow();
        });
        
        
    }
}

