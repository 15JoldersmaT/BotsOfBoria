package pack;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class Ants extends JPanel implements ActionListener {
    private static Timer timer;
    public static List<Being> beings = new ArrayList<>();
    public static List<Scent> scents = new ArrayList<>();
    public static List<Food> foods = new ArrayList<>();
    public static List<Hill> hills = new ArrayList<>();

    private  static int DELAY = 15; // Milliseconds between update/render calls
    
    public static boolean paused = false;
    public static boolean spiderP = false;
    public static boolean mantisP =false;

    public static boolean handP =false;

    private static final Random rand = new Random();

    public static int mX, mY = 0;

    public static int selectedTile = 0;
    public Ants() {
        setPreferredSize(new Dimension(1015, 810));
        setBackground(Color.BLACK);
        
        initGame();
    }

    private void initGame() {
    	
        Color c = new Color(rand.nextInt(155),rand.nextInt(155),rand.nextInt(155));
        for (int i = 0;i<10;i++) {
        	if (i == 0) {
        		c = new Color(53, 39,30);
        	}else if (i == 1) {
        		c = new Color(30, 144, 190);

        	}else if (i == 2) {
        		c = new Color(180, 180, 0);

        	}else if (i == 3) {
        		c = new Color(34, 119, 34);

        	}else if (i == 4) {
        		c = new Color(190, 168 ,161);

        	}else if (i == 6) {
        		c = new Color(180, 40, 147);

        	}
        	else if (i == 9) {
        		c = new Color(190, 105,  0);

        	}
        	else if (i == 7) {
        		c = new Color(104, 36, 109);

        	}else if (i == 8) {
        		c = new Color(110, 110, 40);

        	}else if (i == 5) {
        		c = new Color(190, 0, 0);

        	}
           // c = new Color(rand.nextInt(155),rand.nextInt(155),rand.nextInt(155));

        	Hill h = new Hill(c,rand.nextInt(1000), rand.nextInt(800));
        	hills.add(h);
        }
        
        
        for (int i = 0;i<300;i++) {
        	Food f = new Food(rand.nextInt(1000), rand.nextInt(800));
        	foods.add(f);
        }
        timer = new Timer(100, this);
        timer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        doDrawing(g);
    }

    private void doDrawing(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        
        for (Food food : foods) {
            food.draw(g2d);
            
        }
        for (Hill hill : hills) {
            hill.draw(g2d);
            
        }
        
        for (Scent scent: scents) {
            scent.draw(g2d);
            
        }
        
        
        for (Being being : beings) {
            being.draw(g2d);
            
        }
       
     // Example of adding text to the screen
        if (paused) {
            g2d.setColor(Color.LIGHT_GRAY); // Set the text color

        	g2d.fillRect(850, 50, 150, 390);
            g2d.setColor(Color.WHITE); // Set the text color
            g2d.setFont(new Font("Arial", Font.BOLD, 16)); // Set the font
            g2d.drawString("Game Paused", 850, 20); // Draw the string
            g2d.setFont(new Font("Arial", Font.BOLD, 16)); // Set the font
            g2d.drawString("Total Ants " +  beings.size(), 850, 40); // Draw the string
            
         // Optionally, you can display other information in a similar manner
            // For example, showing coordinates when debugging
            g2d.setColor(Color.YELLOW);
            g2d.setFont(new Font("Arial", Font.PLAIN, 12));
            //g2d.drawString("Mouse X: " + mX + ", Mouse Y: " + mY, 10, 700);
            Map<Color, Integer> colorCounts = new HashMap<>();
            for (Being being : beings) {
                Color color = being.getC();
                colorCounts.put(color, colorCounts.getOrDefault(color, 0) + 1);
            }
            
            int yPos = 70; // Starting Y position for color counts
            g2d.setFont(new Font("Arial", Font.BOLD, 20)); // Set the font larger for color counts

            for (Map.Entry<Color, Integer> entry : colorCounts.entrySet()) {
                g2d.setColor(entry.getKey()); // Set the text color to the being's color
                g2d.drawString(entry.getValue().toString(), 880, yPos);
                yPos += 30; // Move to the next line for each color, with more space due to larger text
            }
            
            // Reset color for any further text
        }
        
        
        
       
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        updateGame();
    }
    
    private void initGameComponents() {
        // Stop the existing timer and clear all action listeners.
        if (timer != null) {
            timer.stop();
            for (ActionListener al : timer.getActionListeners()) {
                timer.removeActionListener(al);
            }
        }
        
        // Reinitialize the game entities.
        beings.clear();
        scents.clear();
        foods.clear();
        hills.clear();
        
        // Re-setup the game environment.
        initGame();
        
        // Reinitialize and start the timer.
        timer = new Timer(DELAY, this);
        timer.start();
    }
    
    private void updateGame() {
    	if(paused == false) {
    		for (int i = 0;i<beings.size();i++) {
        		beings.get(i).update();
        	}
    		for (int i = 0;i<hills.size();i++) {
        		hills.get(i).update();
        	}
    		for (int i = 0;i<scents.size();i++) {
        		scents.get(i).update();
        	}
    		for (int i = 0;i<foods.size();i++) {
        		foods.get(i).update();
        	}
    	}
        repaint();
    }

 

    public static void main(String[] args) {
    	
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Ants!");
            Ants gamePanel = new Ants();
            DELAY = 100;
            gamePanel.initGameComponents(); // Restart game
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.add(gamePanel);
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
            frame.setResizable(false);
            frame.addKeyListener(new KeyAdapter() {
            	
                @Override
                public void keyPressed(KeyEvent e) {
                	
                	if (e.getKeyCode() == KeyEvent.VK_P) { // If 'R' key is pressed
                			
                		
                        	if(paused == false) {
                        		paused = true;
                        	}else {
                        		paused = false;
                        	}
                 
                    }
                	
                	if (e.getKeyCode() == KeyEvent.VK_E) { // If 'R' key is pressed
                		
                    	foods.clear();
             
                	}
                	if (e.getKeyCode() == KeyEvent.VK_1) { // If 'R' key is pressed
                		
                		
                		timer.setDelay(100);;
                		timer.restart();
                       
                    
                        
             
                	}
                	if (e.getKeyCode() == KeyEvent.VK_Q) { // If 'R' key is pressed
                		
                		
                		 for (int i = 0;i<50;i++) {
                	        	Food f = new Food(rand.nextInt(1500), rand.nextInt(800));
                	        	foods.add(f);
                	        }
                       
                    
                        
             
                	}
                	if (e.getKeyCode() == KeyEvent.VK_R) {
                          
                       
                        timer.setDelay(DELAY);;
                        
                        gamePanel.initGameComponents(); // Restart game
                    }
                	if (e.getKeyCode() == KeyEvent.VK_F) {
                		if(DELAY == 1) {
                			//DELAY = 15220;
                		}else {
                			//DELAY = 15;
                		}
                		timer.setDelay(DELAY);;
                		timer.restart();
             
                    }
                	if (e.getKeyCode() == KeyEvent.VK_S) { // If 'R' key is pressed
                		if(spiderP == false) {
                			spiderP = true;
                		}else {
                			spiderP = false;
                		}
                    	
             
                	}
                	
                	if (e.getKeyCode() == KeyEvent.VK_M) { // Toggle Mantis Placement Mode
                        mantisP = !mantisP; // Toggle mantis placement
                        spiderP = !mantisP; // Ensure spider placement is the inverse
                    }
                }
            });
            
            timer.setDelay(DELAY);;
            
            gamePanel.initGameComponents(); // Restart game
            frame.addMouseListener(new MouseAdapter() {
            	public void mouseClicked(MouseEvent e) {
            	    // Calculate the position more directly, potentially centering the food item on the click.
            	    // This example assumes the Food constructor sets the position such that the food is centered on (mX, mY).
            	    mX = e.getX();
            	    mY = e.getY();
            	    
            	    // Optionally adjust for insets if your component has any, like so:
            	    // Insets insets = getInsets();
            	    // mX = mX - insets.left;
            	    // mY = mY - insets.top;

            	    Food f = new Food(mX-15, mY-35); // Assuming Food's constructor or positioning methods handle this smoothly
            	    if (e.getButton() == MouseEvent.BUTTON1) {
                        if (mantisP) { // If mantis mode is enabled, place a mantis
                            Mantis pm = new Mantis(new Color(100,0,0), mX-15, mY-35);
                            
                            beings.add(pm);
                        } else if (spiderP) { // Otherwise, if spider mode is enabled, place a spider
                            Spider sp = new Spider(new Color(100,0,0), mX-15, mY-35);
                            beings.add(sp);
                        } else {
                            // If neither mode is enabled, place food or handle as default action
                            f = new Food(mX-15, mY-35);
                            foods.add(f);
                        }
                    } else if (e.getButton() == MouseEvent.BUTTON3) {
                    	// Right mouse button clicked
            	        // Place one food item at the click position and four others in a box pattern around it

            	        // Distance from the center food to the others
            	        int offset = 20; // Adjust this value to increase or decrease the box size

            	        // Central food
            	        foods.add(new Food(mX-15, mY-35));

            	        // Top food
            	        foods.add(new Food(mX-15, mY-35 - offset));

            	        // Right food
            	        foods.add(new Food(mX-15 + offset, mY-35));

            	        // Bottom food
            	        foods.add(new Food(mX-15, mY-35+ offset));

            	        // Left food
            	        foods.add(new Food(mX-15 - offset, mY-35));
            	                       
            	    } else if (e.getButton() == MouseEvent.BUTTON2) {
                        // Handling for middle-click (placing food with worm property)
                        f = new Food(mX-15, mY-35);
                        f.setWorm(true);
                        foods.add(f);
                    }
            	    
            	   
            	}
                
            });
        });
    }
}