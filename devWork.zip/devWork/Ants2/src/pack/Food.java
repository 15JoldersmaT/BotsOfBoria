package pack;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.Random;

public class Food {
	private int x,y;
	private int energy;
	private boolean meat = false;
	private boolean worm = false;
	private boolean spider = false;
	private String moveCode;
	Random rand = new Random();
	public Food(int x, int y) {
		this.x = x;
		this.y = y;
		this.energy = 4;
	}
	
	
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getEnergy() {
		return energy;
	}
	public void setEnergy(int energy) {
		this.energy = energy;
	}
	
	public void update() {
		if(this.energy <= 0) {
			Ants.foods.remove(this);
		}
		
		if(this.worm == true) {
			if (this.x < 0) {
				this.x = 0;
			}
			if (this.x > 1000) {
				this.x = 1000;
			}
			if (this.y < 0) {
				this.y = 0;
			}
			if(this.y > 800) {
				this.y = 800;
			}
			int mC = rand.nextInt(30);
			if (mC == 0) {
				this.moveCode = "Left";
			}
			else if(mC == 1) {
				this.moveCode = "Right";

			}else if ( mC < 5){
				this.moveCode = "None";

			}
		
			if (this.moveCode == "Left") {
				this.x -= 1;

			}else if(this.moveCode == "Right") {
				this.x += 1;
			}
		}
	}
	public void draw(Graphics2D g2d) {
		g2d.setColor(new Color(136, 103, 78));
		if (this.meat == true) {
			g2d.setColor(new Color(136, 0, 0));
		    g2d.fillOval(x, y, 10, 10); // Draw the outline of a rectangle with x=10, y=10, width=200, and height=100

		}else {
			if(worm == false) {
				g2d.fillOval(x, y, 15, 15); 
			}else{
				g2d.setColor(new Color(255, 105, 180));

				g2d.fillOval(x, y, 45, 10); 

			}
		}
	}


	public boolean isMeat() {
		return meat;
	}


	public void setMeat(boolean meat) {
		this.meat = meat;
	}


	public boolean isWorm() {
		return worm;
	}


	public void setWorm(boolean worm) {
		this.worm = worm;
	}


	public boolean isSpider() {
		return spider;
	}


	public void setSpider(boolean spider) {
		this.spider = spider;
	}

}
