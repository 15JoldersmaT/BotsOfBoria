package pack;

import java.awt.Color;
import java.awt.Graphics2D;

public class Scent {
	
	private String mode = "Leaving";
	private Color c = new Color(255,255,255);
	private int x,y;
	private int id = 0;
	private int strength = 50;
	public static int gID = 0;
	public Scent(Color c, int x, int y, String mode, int ID) {
		this.setC(c);
		this.y = y;
		this.x = x;
		this.mode = mode;
		this.id = ID;
	}
	
	public void draw(Graphics2D g2d) {
		g2d.setColor(this.c);

		if (this.mode == "Leaving") {
		    g2d.drawRect(x, y, 5, 5); // Draw the outline of a rectangle with x=10, y=10, width=200, and height=100

		}else {
		    g2d.drawOval(x, y, 5, 5); // Draw the outline of a rectangle with x=10, y=10, width=200, and height=100

		}
	    
	}
	
	public void update() {
		this.strength -=1;
		if (this.strength < 1) {
			Ants.scents.remove(this);
		}
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public Color getC() {
		return c;
	}

	public void setC(Color c) {
		this.c = c;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getStrength() {
		return strength;
	}

	public void setStrength(int strength) {
		this.strength = strength;
	}
	

}
