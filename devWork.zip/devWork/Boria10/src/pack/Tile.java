package pack;


import java.util.ArrayList;
import java.util.List;

public class Tile {
    private List<Bot> bots;
    private int x, y;
    private int g;

    public Tile(int x, int y) {
        this.x = x;
        this.y = y;
        this.bots = new ArrayList<>(); // Properly initialize the list of bots.
    }

    public void update() {
        // Clear the list of bots as we will recheck their positions
        bots.clear();

        // Iterate over all bots to check if they are within the tile's bounds
        for (Bot bot : Boria.bots) {
            if (isBotInTile(bot)) {
                bots.add(bot);
               // bot.setTile(this); // Assuming setTile is a method you need
            }
        }

        // Optional: If debugging is necessary, consider logging this less frequently or under certain conditions
        // System.out.println("Test");
    }

    private boolean isBotInTile(Bot bot) {
        // Check if the bot is within the bounds of the tile
        return bot.getX() >= this.x && bot.getX() < this.x + 100 &&
               bot.getY() >= this.y && bot.getY() < this.y + 100;
    }

    public List<Bot> getBots() {
        return bots;
    }

    public void setBots(List<Bot> bots) {
        this.bots = bots;
    }

    public int getG() {
        return g;
    }

    public void setG(int g) {
        this.g = g;
    }

    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }
}
