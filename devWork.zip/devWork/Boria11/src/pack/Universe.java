package pack;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Random;

public class Universe {
	
	public static double grav = 0.0;
	static Random rand = new Random();
	public static double g1 = 0.0;
	public static double g2 = 0.0;
	public static double g3 = 0.0;
	public static double g4 = 0.0;
	public static double g5 = 0.0;
	public static double g6 = 0.0;
	public static double g7 = 0.0;
	public static double g8 = 0.0;
	public static double g9 = 0.0;
	public static double g10 = 0.0;
	public static double g11 = 0.0;
	public static double g12 = 0.0;
	public static double g13 = 0.0;
	public static double g14 = 0.0;
	public static double g15 = 0.0;
	public static double g16 = 0.0;
	public static double g17 = 0.0;
	public static double g18 = 0.0;
	public static double g19 = 0.0;
	public static double g20 = 0.0;
	public static double g21 = 0.0;
	public static double g22 = 0.0;
	public static double g23 = 0.0;
	public static double g24 = 0.0;
	public static double g25 = 0.0;
	public static double g26 = 0.0;
	public static double g27 = 0.0;
	public static double g28 = 0.0;
	public static double g29 = 0.0;
	public static double g30 = 0.0;
	public static double g31 = 0.0;
	public static double g32 = 0.0;
	public static double g33 = 0.0;
	public static double g34 = 0.0;
	public static double g35 = 0.0;
	public static double g36 = 0.0;
	public static double g37 = 0.0;
	public static double g38 = 0.0;
	public static double g39 = 0.0;
	public static double g40 = 0.0;
	public static double g41 = 0.0;
	public static double g42 = 0.0;
	public static double g43 = 0.0;
	public static double g44 = 0.0;
	public static double g45 = 0.0;
	public static double g46 = 0.0;
	public static double g47 = 0.0;
	public static double g48 = 0.0;
	
	public static int gDist  = rand.nextInt(650)+50;

	public static int c1  = rand.nextInt(2);
	public static int c2  = rand.nextInt(2);
	public static int c3  = rand.nextInt(2);
	public static int c4  = rand.nextInt(2);
	public static int c5  = rand.nextInt(2);
	public static int c6  = rand.nextInt(2);
	public static int c7  = rand.nextInt(2);
	
	public static double frictionCoefficientC1 = rand.nextDouble(); // Generates a value between 0.0 (inclusive) and 1.0 (exclusive)
	public static double frictionCoefficientC2 = rand.nextDouble(); // Generates a value between 0.0 (inclusive) and 1.0 (exclusive)
	public static double frictionCoefficientC3 = rand.nextDouble(); // Generates a value between 0.0 (inclusive) and 1.0 (exclusive)
	public static double frictionCoefficientC4 = rand.nextDouble(); // Generates a value between 0.0 (inclusive) and 1.0 (exclusive)
	public static double frictionCoefficientC5 = rand.nextDouble(); // Generates a value between 0.0 (inclusive) and 1.0 (exclusive)
	public static double frictionCoefficientC6 = rand.nextDouble(); // Generates a value between 0.0 (inclusive) and 1.0 (exclusive)
	public static double frictionCoefficientC7 = rand.nextDouble(); // Generates a value between 0.0 (inclusive) and 1.0 (exclusive)

	public static int d1 =rand.nextInt(3);
	public static int d2 =rand.nextInt(3);
	public static int d3 =rand.nextInt(3);
	public static int d4 =rand.nextInt(3);
    public static int d5 =rand.nextInt(3);
    public static int d6 =rand.nextInt(3);
    public static int d7 =rand.nextInt(3);



	public static int cc1 =rand.nextInt(10);
	public static int cc2 =rand.nextInt(10);
	public static int cc3 =rand.nextInt(10);
	public static int cc4 =rand.nextInt(10);
	public static int cc5 =rand.nextInt(10);
	public static int cc6 =rand.nextInt(10);
	public static int cc7 =rand.nextInt(10);

	
	public static int sc1 =0;
	public static int sc2 =0;
	public static int sc3 =0;
	public static int sc4 =0;
	public static int sc5 =0;
	public static int sc6 =0;
	public static int sc7 =0;
	
	public static Color c11 = new Color(255,0,0);
	public static Color c12 = new Color(255,0,0);
	public static Color c13 = new Color(255,0,0);
	public static Color c14 = new Color(255,0,0);
	public static Color c15 = new Color(255,0,0);
	public static Color c16 = new Color(255,0,0);
	public static Color c17 = new Color(255,0,0);
	
	
	public static String c1M = "e";
	public static String c2M = "e";
	public static String c3M = "e";
	public static String c4M = "e";
	public static String c5M = "e";
	public static String c6M = "e";
	public static String c7M = "e";
	
	private static Color[] colors = {
	        new Color(255, 0, 0),
	        new Color(0, 255, 0),
	        new Color(0, 0, 255),
	        new Color(255, 165, 0),
	        new Color(0, 255, 255),
	        new Color(215, 134, 18),
	        new Color(200, 55, 187)
	    };
	
	public Universe() {
		
	}
	
	public void reset() {
		 
    	 
		 gDist  = rand.nextInt(150)+150;
		 if (Boria.big == true) {
			 gDist  = rand.nextInt(1250)+50;
    	 }
		 if (Boria.little == true) {
			 
			 gDist  = rand.nextInt(150)+100;
			 if (Boria.col == true) {
				 gDist = rand.nextInt(150) + 50;
			 }
    	 }
		 if (Boria.reallyLittle == true) {
			 
			 gDist  = rand.nextInt(50)+25;
			 if (Boria.col == true) {
				 gDist = rand.nextInt(50) + 50;
			 }
    	 }
		 c11 = colors[rand.nextInt(colors.length)];
		 c12 = colors[rand.nextInt(colors.length)];
		 c13 = colors[rand.nextInt(colors.length)];
		 c14 = colors[rand.nextInt(colors.length)];
		 c15 = colors[rand.nextInt(colors.length)];
		 c16 = colors[rand.nextInt(colors.length)];
		 c17 = colors[rand.nextInt(colors.length)];

		 c1  = rand.nextInt(2);
		 c2  = rand.nextInt(2);
		 c3  = rand.nextInt(2);
		 c4  = rand.nextInt(2);
		 c5  = rand.nextInt(2);
		 c6  = rand.nextInt(2);
		 c7  = rand.nextInt(2);
		 
		 if(Boria.uMode == true) {
		
			 int c1MM  = rand.nextInt(3);
			 int c2MM  = rand.nextInt(3);
			 int c3MM  = rand.nextInt(3);
			 int c4MM  = rand.nextInt(3);
			 int c5MM  = rand.nextInt(3);
			 int c6MM  = rand.nextInt(3);
			 int c7MM  = rand.nextInt(3);
			 
			 if (c1MM == 0) {
					c1M = "e";
	
			 }else if (c1MM == 1) {
					c1M = "s";
	
			 }else if (c1MM == 2) {
					c1M = "n";
	
			 }
			 
			 if (c2MM == 0) {
					c2M = "e";
	
			 }else if (c2MM == 1) {
					c2M = "s";
	
			 }else if (c2MM == 2) {
					c2M = "n";
	
			 }
			 
			 if (c3MM == 0) {
					c3M = "e";
	
			 }else if (c3MM == 1) {
					c3M = "s";
	
			 }else if (c3MM == 2) {
					c3M = "n";
	
			 }
			 
			 if (c4MM == 0) {
					c4M = "e";
	
			 }else if (c4MM == 1) {
					c4M = "s";
	
			 }else if (c4MM == 2) {
					c4M = "n";
	
			 }
			 
			 if (c5MM == 0) {
					c5M = "e";
	
			 }else if (c5MM == 1) {
					c5M = "s";
	
			 }else if (c5MM == 2) {
					c5M = "n";
	
			 }
			 
			 if (c6MM == 0) {
					c6M = "e";
	
			 }else if (c6MM == 1) {
					c6M = "s";
	
			 }else if (c6MM == 2) {
					c6M = "n";
	
			 }
			 
			 if (c7MM == 0) {
					c7M = "e";
	
			 }else if (c7MM == 1) {
					c7M = "s";
	
			 }else if (c7MM == 2) {
					c7M = "n";
	
			 }
		 }
			
		 d1 = rand.nextInt(16);
		 d2 = rand.nextInt(16);
		 d3 = rand.nextInt(16);
		 d4 = rand.nextInt(16);
		 d5 = rand.nextInt(16);
		 d6 = rand.nextInt(16);
		 d7 = rand.nextInt(16);
		 
		 cc1 =rand.nextInt(10);
		 cc2 =rand.nextInt(10);
		 cc3 =rand.nextInt(10);
		 cc4 =rand.nextInt(10);
		 cc5 =rand.nextInt(10);
		 cc6 =rand.nextInt(10);
		 cc7 =rand.nextInt(10);

		 g1 = rand.nextDouble() *2- 1; 
	     g2 = rand.nextDouble() *2- 1; 
	     g3 = rand.nextDouble() *2- 1;
	     g4 = rand.nextDouble() *2- 1; 
	     g5 = rand.nextDouble() *2- 1; 
	     g6 = rand.nextDouble() *2- 1;
	     g7 = rand.nextDouble() *2- 1; 
	     g8 = rand.nextDouble() *2- 1; 
	     g9 = rand.nextDouble() *2- 1;
	     g10 = rand.nextDouble() *2- 1; 
	     g11 = rand.nextDouble() *2- 1; 
	     g12 = rand.nextDouble() *2- 1;
	     g13 = rand.nextDouble() *2- 1; 
	     g14 = rand.nextDouble() *2- 1; 
	     g15 = rand.nextDouble() *2- 1;
	     g16 = rand.nextDouble() *2- 1; 
	     g17 = rand.nextDouble() *2- 1; 
	     g18 = rand.nextDouble() *2- 1;
	     g19 = rand.nextDouble() *2- 1; 
	     g20 = rand.nextDouble() *2- 1; 
	     g21 = rand.nextDouble() *2- 1;
	     g21 = rand.nextDouble() *2- 1; 
	     g22 = rand.nextDouble() *2- 1; 
	     g23 = rand.nextDouble() *2- 1;
	     g24 = rand.nextDouble() *2- 1; 
	     g25 = rand.nextDouble() *2- 1; 
	     g26 = rand.nextDouble() *2- 1;
	     g27 = rand.nextDouble() *2- 1; 
	     g28 = rand.nextDouble() *2- 1; 
	     g29 = rand.nextDouble() *2- 1;
	     g30 = rand.nextDouble() *2- 1; 
	     g31 = rand.nextDouble() *2- 1; 
	     g32 = rand.nextDouble() *2- 1;
	     g33 = rand.nextDouble() *2- 1; 
	     g34 = rand.nextDouble() *2- 1; 
	     g35 = rand.nextDouble() *2- 1;
	     g36 = rand.nextDouble() *2- 1; 
	     g37 = rand.nextDouble() *2- 1; 
	     g38 = rand.nextDouble() *2- 1;
	     g39 = rand.nextDouble() *2- 1; 
	     g40 = rand.nextDouble() *2- 1; 
	     g41 = rand.nextDouble() *2- 1;
	     g42 = rand.nextDouble() *2- 1; 
	     g43 = rand.nextDouble() *2- 1; 
	     g44 = rand.nextDouble() *2- 1; 
	     g45 = rand.nextDouble() *2- 1;
	     g46 = rand.nextDouble() *2- 1; 
	     g47 = rand.nextDouble() *2- 1;
	     g48 = rand.nextDouble() *2- 1; 
	     
	     grav = (rand.nextDouble()  * 550) + 150 ;
	     if(Boria.little != true) {
		     grav = (rand.nextDouble()  * 150) + 50 ;
	     }
	     Bot botty = new Bot(0,0, new Color(255,255,255));
    	 int cg = rand.nextInt(2);
    	 
    	 if (Boria.col == true) {
    	        grav =(rand.nextDouble()  * 15) + 15 ;

    	        // Populate the bots list
    		 	Boria.bots.clear();
    		 	int spawnNum = 600;
        		if (Boria.high == true) {
        			spawnNum = 800;
        		}
        		if (Boria.kMode == true) {
        			spawnNum = 900;
        		}
    	        for (int i = 0; i < spawnNum; i++) { // Example: creating 100 bots
    	        	 int x = rand.nextInt(1300);
    		    	 int y = rand.nextInt(800);
    		    	 botty.setX(x);
    		    	 botty.setY(y);
    		    	 int c = rand.nextInt(7);
    		    	if (cg == 0) {
    			    	if (c == 0) {
    				         botty.setColor(new Color (255,0,0));
    			    	}else if (c == 1) {
    			    		botty.setColor(new Color (0, 255, 0));
    			        }else if (c == 2) {
    			        	botty.setColor(new Color (0, 0, 255));
    			        }else if (c == 3) {
    			        	botty.setColor(new Color (255, 165, 0));
    			        }else if (c == 4) {
    			        	botty.setColor(new Color (0, 255, 255));
    			        }else if (c == 5) {
    			        	botty.setColor(new Color (215, 134, 18));
    			        }else if (c == 6) {
    			        	botty.setColor(new Color (200, 55, 187));
    			        }
    		    	}else if (cg == 1) {
    			    	if (c == 0) {
    			    		botty.setColor(new Color (255,0,0));
    			    	}else {
    			    		botty.setColor(new Color (0, 255, 0));
    			    	}
    		    	}else {
    		    		if (c == 0 || c== 1 || c== 2) {
    		    			botty.setColor(new Color (255,0,0));
    			    	}else if (c == 3 || c == 4 || c== 5) {
    			    		botty.setColor(new Color (0, 255, 0));
    			        }else
    			        	botty.setColor(new Color (0, 0, 255));
    			        
    		    	}
    		    	  Bot bb = botty;
    	    	      Boria.bots.add(new Bot(rand.nextInt(1300),rand.nextInt(800),botty.getColor())); 
    	        }
    	        
    	 }
    	 if (Boria.col == false) {

    		 Boria.bots.clear();
    		 int spawnNum = 1850;
    		if (Boria.high == true) {
    			spawnNum = 2300;
    		}
    		if (Boria.kMode == true) {
    			spawnNum = 5800;
    		}
    		sc1 = 0;
    		sc2 = 0;
    		sc3 = 0;
    		sc4 = 0;
    		sc5 = 0;
    		sc6 = 0;
    		sc7 = 0;

 	        for (int i = 0; i < spawnNum; i++) { // Example: creating 100 bots
 	        
 		    	 int c = rand.nextInt(7);
 		    	if (cg == 0) {
 			    	if (c == 0) {
 				         botty.setColor(new Color (255,0,0));
 				         sc1+=1;
 			    	}else if (c == 1) {
 			    		botty.setColor(new Color (0, 255, 0));
				         sc2+=1;

 			        }else if (c == 2) {
 			        	botty.setColor(new Color (0, 0, 255));
				         sc3+=1;

 			        }else if (c == 3) {
 			        	botty.setColor(new Color (255, 165, 0));
				         sc4+=1;

 			        }else if (c == 4) {
 			        	botty.setColor(new Color (0, 255, 255));
				         sc5+=1;

 			        }else if (c == 5) {
 			        	botty.setColor(new Color (215, 134, 18));
				         sc6+=1;

 			        }else if (c == 6) {
 			        	botty.setColor(new Color (200, 55, 187));
				         sc7+=1;

 			        }
 		    	}else if (cg == 1) {
 			    	if (c == 0) {
 			    		botty.setColor(new Color (255,0,0));
				         sc1+=1;

 			    	}else {
 			    		botty.setColor(new Color (0, 255, 0));
				         sc2+=1;

 			    	}
 		    	}else {
 		    		if (c == 0 || c== 1 || c== 2) {
 		    			botty.setColor(new Color (255,0,0));
				         sc1+=1;

 			    	}else if (c == 3 || c == 4 || c== 5) {
 			    		botty.setColor(new Color (0, 255, 0));
				         sc2+=1;

 			        }else
 			        	botty.setColor(new Color (0, 0, 255));
 		    			sc3 +=1;
 			        
 		    	}
 		    	  Bot bb = botty;
 	    	      Boria.bots.add(new Bot(rand.nextInt(1100),rand.nextInt(700),botty.getColor())); 
 	        }
    	 }
	}
	
	public void lightReset() {
	    int startSize = Boria.bots.size();
	    Boria.bots.clear();

	    for (int i = 0; i < startSize; i++) {
	        Color colorN = new Color(255, 0, 0);
	        if (i < sc1) {
	            colorN = new Color(255, 0, 0);
	        } else if (i < sc1 + sc2) {
	            colorN = new Color(0, 255, 0);
	        } else if (i < sc1 + sc2 + sc3) {
	            colorN = new Color(0, 0, 255);
	        } else if (i < sc1 + sc2 + sc3 + sc4) {
	            colorN = new Color(255, 165, 0);
	        } else if (i < sc1 + sc2 + sc3 + sc4 + sc5) {
	            colorN = new Color(0, 255, 255);
	        } else if (i < sc1 + sc2 + sc3 + sc4 + sc5 + sc6) {
	            colorN = new Color(215, 134, 18);
	        } else if (i < sc1 + sc2 + sc3 + sc4 + sc5 + sc6 + sc7) {
	            colorN = new Color(200, 55, 187);
	        }
	        Boria.bots.add(new Bot(rand.nextInt(1100), rand.nextInt(700), colorN));
	    }
	}

}
