package pack;

import javax.sound.sampled.*;

public class AudioInput {
    private TargetDataLine line;
    private AudioInputStream audioInputStream;
    private static final int BUFFER_SIZE = 256;
    private static final double EXPANSION_FACTOR = 1.0; // Adjust this value to control the expansion

    public AudioInput() throws LineUnavailableException {
        AudioFormat format = new AudioFormat(44100, 16, 1, true, true);
        DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
        if (!AudioSystem.isLineSupported(info)) {
            throw new LineUnavailableException();
        }

        line = (TargetDataLine) AudioSystem.getLine(info);
        line.open(format);
        line.start();

        audioInputStream = new AudioInputStream(line);
    }

    public float getDecibels() throws Exception {
        byte[] buffer = new byte[BUFFER_SIZE];
        int bytesRead = audioInputStream.read(buffer, 0, buffer.length);

        if (bytesRead <= 0) return 0;

        long sum = 0;
        for (int i = 0; i < bytesRead; i += 2) {
            int sample = (buffer[i + 1] << 8) | (buffer[i] & 0xFF);
            sum += sample * sample;
        }

        double rms = Math.sqrt(sum / (double)(bytesRead / 2));

        // Apply dynamic range expansion
        double expandedRms = Math.pow(rms, EXPANSION_FACTOR);

        // Calculate decibels
        float decibels = (float) (20 * Math.log10(expandedRms + 1e-6)); // Avoid log(0)

        // Debugging output
        System.out.println("Bytes Read: " + bytesRead);
        System.out.println("RMS: " + rms);
        System.out.println("Expanded RMS: " + expandedRms);
        System.out.println("Decibels: " + decibels);

        return decibels;
    }

    public void close() {
        line.stop();
        line.close();
    }
}
