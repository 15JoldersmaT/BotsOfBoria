package pack;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.sound.sampled.LineUnavailableException;
import java.util.LinkedList;
import java.util.Queue;

public class Boria extends JPanel implements ActionListener {
    private Timer timer;
    private ExecutorService executor;
    public static List<Bot> bots;
    public static List<Tile> tiles;

    private static final int DELAY = 45;
    public static Universe u = new Universe();

    public static boolean big = false;
    public static boolean little = false;
    public static boolean reallyLittle = false;
    public static boolean kMode = false;
    public static boolean nMode = false;
    public static boolean sMode = false;
    public static boolean dMode = false;
    public static boolean uMode = true;

    public static boolean high = false;
    public static boolean gravityM = false;

    public static boolean col = false;

    public static boolean auto = false;
    public static int countDown = 1000;
    public static boolean emptyMode = false;
    public static Random rand = new Random();

    public static boolean gravity = false;
    public static boolean gravityC = false;

    public static int sTime = 1;
    public static boolean white;
    public static boolean weird;
    public static boolean weird2;
    public static boolean weird3;
    public static boolean weird4;
    public static boolean weird5;
    public static boolean weird6;
    public static boolean weird7;
    public static boolean weird8;
    public static boolean weird9;
    public static boolean weird10;
    public static boolean weird11;
    public static boolean weird12;
    public static boolean weird13;
    public static boolean weird14;

    private static boolean isPaused = false;
    public static boolean weird15;
    public static boolean weird16;
    public static boolean weird17;
    public static boolean weird18;
    public static boolean weird20;

    private AudioInput audioInput;

    public Boria() {
        setPreferredSize(new Dimension(1100, 700));
        setBackground(Color.BLACK);
        initGame();

        try {
            audioInput = new AudioInput();
        } catch (LineUnavailableException e) {
            e.printStackTrace();
        }
    }

    private void initGame() {
        bots = new ArrayList<>();
        tiles = new ArrayList<>();

        // Populate the bots list
        for (int i = 0; i < 3500; i++) {
            bots.add(new Bot(650, 400, new Color(255, 0, 0))); // Starting all bots at the center for simplicity
        }

        // Populate the tiles list
        int tx, ty;
        int startX = 0, startY = 0;
        for (int i = 0; i < 225; i++) {
            tx = startX * 100;
            ty = startY * 100;
            startX += 1;
            if (startX > 15) {
                startY += 1;
                startX = 0;
            }
            tiles.add(new Tile(tx, ty));
        }

        executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

        timer = new Timer(DELAY, this);
        timer.start();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        doDrawing(g);
    }

    private void doDrawing(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.WHITE);
        g.fillRect(0, 0, 1200, 1200);
        if (!weird && !weird2 && !weird4 && !weird7 && !weird8 && !weird9 && !weird10 && !weird11 && !weird12 && !weird13 && !weird14) {
            g2d.setColor(new Color(0, 0, 0));
        } else if (weird2) {
            g2d.setColor(new Color(210, 210, 110));
        } else if (weird4) {
            g2d.setColor(new Color(209, 184, 205));
        } else if (weird8) {
            g2d.setColor(new Color(210, 169, 147));
        } else if (weird9) {
            g2d.setColor(new Color(40, 85, 204));
        } else if (weird10) {
            g2d.setColor(new Color(34, 47, 62)); // Winter theme background
        } else if (weird11) {
            g2d.setColor(new Color(72, 20, 0)); // Fire theme background
        } else if (weird12) {
            g2d.setColor(new Color(255, 223, 186)); // Beach Time theme background
        } else if (weird13) {
            g2d.setColor(new Color(128, 70, 27)); // Autumn theme background
        } else if (weird14) {
            g2d.setColor(new Color(0, 0, 100)); // Spring theme background
        } else {
            g2d.setColor(Color.WHITE);
        }
        g.fillRect(10, 10, 1080, 680);
        for (Bot bot : bots) {
            bot.draw(g2d);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        updateGame();
        repaint();
    }

    private void updateGame() {
        if (!isPaused) {
            countDown -= 1;
            if (auto) {
                System.out.println(countDown);
                if (countDown < 1) {
                    countDown = 500;
                    int sChance = rand.nextInt(5);
                    int gChance = rand.nextInt(6);
                    int cChance = rand.nextInt(5);
                    int dChance = rand.nextInt(5);

                    little = dChance <= 2;
                    big = dChance == 4;
                    high = sChance <= 2;
                    gravity = gChance < 3;
                    gravityC = gChance < 5;
                    col = cChance > 3;
                    u.reset();
                }
            }

            float decibels = getDecibelsFromAudio();

            for (Bot bot : bots) {
                final float botDecibels = decibels;
                executor.submit(() -> bot.update(botDecibels));
            }

            for (Tile tile : tiles) {
                executor.submit(tile::update);
            }
        }
    }

    private float getDecibelsFromAudio() {
        float decibels = 0;
        try {
            decibels = audioInput.getDecibels();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return decibels;
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Bots of Boria");
            Boria simulation = new Boria();
            u.reset();
            frame.add(simulation);
            frame.setResizable(false);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);

            frame.addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                    switch (e.getKeyCode()) {
                        case KeyEvent.VK_H:
                            System.out.println("high");
                            high = !high;
                            break;
                        case KeyEvent.VK_8:
                            big = false;
                            little = true;
                            reallyLittle = false;
                            uMode = true;
                            break;
                        case KeyEvent.VK_9:
                            big = false;
                            little = true;
                            reallyLittle = true;
                            uMode = true;
                            break;
                        case KeyEvent.VK_0:
                            big = true;
                            little = false;
                            reallyLittle = false;
                            uMode = true;
                            break;
                        case KeyEvent.VK_E:
                            weird18 = !weird18;
                            break;
                        case KeyEvent.VK_R:
                            bots.clear();
                            tiles.clear();
                            u.reset();
                            simulation.repaint();
                            break;
                        case KeyEvent.VK_G:
                            gravity = !gravity;
                            break;
                        case KeyEvent.VK_M:
                            gravityM = !gravityM;
                            break;
                        case KeyEvent.VK_N:
                            uMode = false;
                            nMode = true;
                            big = false;
                            reallyLittle = false;
                            little = false;
                            break;
                        case KeyEvent.VK_S:
                            weird20 = !weird20;
                            break;
                        case KeyEvent.VK_F:
                            gravityC = !gravityC;
                            break;
                        case KeyEvent.VK_B:
                            // big = !big;
                            // break;
                        case KeyEvent.VK_D:
                            dMode = !dMode;
                            break;
                        case KeyEvent.VK_C:
                            col = !col;
                            u.reset();
                            simulation.repaint();
                            break;
                        case KeyEvent.VK_L:
                            weird14 = !weird14;
                            weird = false;
                            weird2 = false;
                            weird4 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird5 = false;
                            weird9 = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            break;
                        case KeyEvent.VK_Z:
                            weird15 = !weird15;
                            break;
                        case KeyEvent.VK_X:
                            weird16 = !weird16;
                            break;
                        case KeyEvent.VK_W:
                            white = !white;
                            break;
                        case KeyEvent.VK_1:
                            weird = !weird;
                            weird2 = false;
                            weird4 = false;
                            weird5 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird9 = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            break;
                        case KeyEvent.VK_2:
                            weird2 = !weird2;
                            weird = false;
                            weird4 = false;
                            weird5 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird9 = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            break;
                        case KeyEvent.VK_3:
                            weird3 = !weird3;
                            break;
                        case KeyEvent.VK_4:
                            weird4 = !weird4;
                            weird2 = false;
                            weird = false;
                            weird5 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird9 = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            break;
                        case KeyEvent.VK_5:
                            weird5 = !weird5;
                            weird2 = false;
                            weird4 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird9 = false;
                            weird = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            break;
                        case KeyEvent.VK_6:
                            weird6 = !weird6;
                            weird2 = false;
                            weird4 = false;
                            weird7 = false;
                            weird8 = false;
                            weird9 = false;
                            weird = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            break;
                        case KeyEvent.VK_7:
                            weird7 = !weird7;
                            weird2 = false;
                            weird4 = false;
                            weird6 = false;
                            weird8 = false;
                            weird9 = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            weird = false;
                            break;
                        case KeyEvent.VK_O:
                            weird8 = !weird8;
                            weird = false;
                            weird4 = false;
                            weird6 = false;
                            weird7 = false;
                            weird2 = false;
                            weird5 = false;
                            weird9 = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            break;
                        case KeyEvent.VK_T:
                            weird9 = !weird9;
                            weird = false;
                            weird2 = false;
                            weird4 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird5 = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            break;
                        case KeyEvent.VK_Y:
                            weird10 = !weird10;
                            weird = false;
                            weird2 = false;
                            weird4 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird5 = false;
                            weird9 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            break;
                        case KeyEvent.VK_K:
                            weird11 = !weird11;
                            weird = false;
                            weird2 = false;
                            weird4 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird5 = false;
                            weird9 = false;
                            weird10 = false;
                            weird12 = false;
                            weird13 = false;
                            break;
                        case KeyEvent.VK_I:
                            weird12 = !weird12;
                            weird = false;
                            weird2 = false;
                            weird4 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird5 = false;
                            weird9 = false;
                            weird10 = false;
                            weird11 = false;
                            weird13 = false;
                            break;
                        case KeyEvent.VK_A:
                            weird13 = !weird13;
                            weird = false;
                            weird2 = false;
                            weird4 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird5 = false;
                            weird9 = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            break;
                        case KeyEvent.VK_U:
                            weird17 = !weird17;
                            break;
                        case KeyEvent.VK_SPACE:
                            u.lightReset();
                            simulation.repaint();
                            break;
                        case KeyEvent.VK_Q:
                            reallyLittle = !reallyLittle;
                            break;
                        case KeyEvent.VK_P:
                            isPaused = !isPaused;
                            break;
                    }
                }
            });

            try {
                Thread.sleep(sTime);
            } catch (InterruptedException e1) {
                e1.printStackTrace();
            }

            frame.setFocusable(true);
            frame.requestFocusInWindow();
        });
    }
}
