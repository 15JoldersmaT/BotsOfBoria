package pack;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Boria extends JPanel implements ActionListener {
    private Timer timer;
    private ExecutorService executor;
    public static List<Bot> bots;
    public static List<Tile> tiles;

    private static int DELAY = 45; // Milliseconds between update/render calls
    public static Universe u = new Universe();

    public static boolean big = false;
    public static boolean little = false;
    public static boolean reallyLittle = false;
    public static boolean kMode = false;
    public static boolean nMode = false;
    public static boolean sMode = false;
    public static boolean dMode = false;
    public static boolean uMode = true;
    public static boolean metallicMode = false;
    public static boolean translucencyMode = false;
    
    public static boolean high = false;
    public static boolean lLow = false;

    public static boolean gravityM = false;

    public static boolean col = false;

    public static boolean auto = false;
    public static int countDown = 1000;
    public static boolean emptyMode = false;
    public static Random rand = new Random();

    public static boolean gravity = false;
    public static boolean gravityC = false;

    public static int sTime = 1;
    public static boolean white;
    public static boolean weird;
    public static boolean weird2;
    public static boolean weird3;
    public static boolean weird4;
    public static boolean weird5;
    public static boolean weird6;
    public static boolean weird7;
    public static boolean weird8;
    public static boolean weird9;
    public static boolean weird10;
    public static boolean weird11;
    public static boolean weird12;
    public static boolean weird13;
    public static boolean weird14;
    public static boolean weird21;
    public static boolean weird22;
    public static boolean weird24;
    public static boolean weird25;

    private static boolean isPaused = false; // Added to keep track of pause state
    public static boolean weird15;
    public static boolean weird16;
    public static boolean weird17;
    public static boolean weird18;
    public static boolean mixedMode;
    public static Map<Color, boolean[]> colorEffects = new HashMap<>();
    private static final Random random = new Random();

    // Define colors
    private static final Color[] COLORS = {
        new Color(255, 0, 0),     // Red
        new Color(0, 255, 0),     // Green
        new Color(0, 0, 255),     // Blue
        new Color(255, 165, 0),   // Orange
        new Color(0, 255, 255),   // Cyan
        new Color(200, 55, 187),  // Purple
        new Color(215, 134, 18)   // Brown
    };

    // Initialize color effects for each color
    static {
        randomizeEffects();
    }

    // Method to generate random effects
    public static void randomizeEffects() {
        for (Color color : COLORS) {
            boolean[] effects = new boolean[6]; // Add an extra boolean for fill/draw
            for (int i = 0; i < effects.length; i++) {
                effects[i] = random.nextBoolean();
            }
            colorEffects.put(color, effects);
        }
    }



    public Boria() {
        setPreferredSize(new Dimension(1100, 700));
        setBackground(Color.BLACK);
        initGame();
    }

    private void initGame() {
        bots = new ArrayList<>();
        tiles = new ArrayList<>();

        // Populate the bots list
        for (int i = 0; i < 3500; i++) {
            bots.add(new Bot(650, 400, new Color(255, 0, 0))); // Starting all bots at the center for simplicity
        }

        // Populate the tiles list
        int tx, ty;
        int startX = 0, startY = 0;
        for (int i = 0; i < 225; i++) {
            tx = startX * 100;
            ty = startY * 100;
            startX += 1;
            if (startX > 15) {
                startY += 1;
                startX = 0;
            }
            tiles.add(new Tile(tx, ty));
        }

        // Reuse a single ExecutorService
        executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

        timer = new Timer(DELAY, this);
        timer.start();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        doDrawing(g);
    }

    private void doDrawing(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.WHITE);
        g.fillRect(0, 0, 1200, 1200);
     // Background matching
        if (!weird && !weird22 && !weird25 && !weird24 && !weird2 && !weird4 && !weird7 && !weird8 && !weird9 && !weird10 && !weird11 && !weird12 && !weird13 && !weird14 && !weird21) {
            g2d.setColor(new Color(0, 0, 0)); // Default black
        } else if (weird2) {
            g2d.setColor(new Color(255, 228, 196)); // Soft Beige
        } else if (weird4) {
            g2d.setColor(new Color(224, 255, 255)); // Light Cyan
        } else if (weird8) {
            g2d.setColor(new Color(245, 245, 220)); // Warm Beige
        } else if (weird9) {
            g2d.setColor(new Color(50, 50, 50)); // Dark Gray
        } else if (weird10) {
            g2d.setColor(new Color(10, 20, 60)); // Deep Navy
        } else if (weird11) {
            g2d.setColor(new Color(80, 0, 100)); // Dark Purple
        } else if (weird12) {
            g2d.setColor(new Color(20, 70, 20)); // Forest Green
        } else if (weird13) {
            g2d.setColor(new Color(80, 40, 20)); // Deep Brown
        } else if (weird14) {
            g2d.setColor(new Color(0, 30, 60)); // Muted Blue
        } else if (weird21) {
            g2d.setColor(new Color(30, 30, 30)); // Dark Charcoal
        } else if (weird22) {
            g2d.setColor(new Color(200, 220, 180)); // Pale Green
        } else if (weird24) {
            g2d.setColor(new Color(10, 10, 80)); // Midnight Blue
        } else if (weird25) {
            g2d.setColor(new Color(120, 0, 30)); // Deep Burgundy
        } else {
            g2d.setColor(Color.WHITE); // Default white
        }
        g.fillRect(10, 10, 1080, 680);
        for (Bot bot : bots) {
            bot.draw(g2d);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        updateGame();
        repaint();
    }

    private void updateGame() {
        if (!isPaused) {
            countDown -= 1;
            if (auto) {
                System.out.println(countDown);
                if (countDown < 1) {
                    countDown = 500;
                    int sChance = rand.nextInt(5);
                    int gChance = rand.nextInt(6);
                    int cChance = rand.nextInt(5);
                    int dChance = rand.nextInt(5);

                    little = dChance <= 2;
                    big = dChance == 4;
                    high = sChance <= 2;
                    gravity = gChance < 3;
                    gravityC = gChance < 5;
                    col = cChance > 3;
                    u.reset(); // Call the static reset method
                }
            }

            // Submit bot update tasks to the executor
            for (Bot bot : bots) {
                executor.submit(bot::update);
            }

            // Submit tile update tasks to the executor
            for (Tile tile : tiles) {
                executor.submit(tile::update);
            }
        }
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Bots of Boria");
            Boria simulation = new Boria();
            u.reset();
            frame.add(simulation);
            frame.setResizable(false);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);

            frame.addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                    switch (e.getKeyCode()) {
                        case KeyEvent.VK_H:
                            System.out.println("high");
                            high = !high;
                            break;
                        case KeyEvent.VK_8:
                            big = false;
                            little = true;
                            reallyLittle = false;
                            uMode = true;
                            break;
                        case KeyEvent.VK_9:
                            big = false;
                            little = true;
                            reallyLittle = true;
                            uMode = true;
                            break;
                        case KeyEvent.VK_0:
                            big = true;
                            little = false;
                            reallyLittle = false;
                            uMode = true;
                            break;
                        case KeyEvent.VK_E:
                            weird18 = !weird18;
                            break;
                        case KeyEvent.VK_R:
                            bots.clear();
                            tiles.clear();
                            u.reset();
                            simulation.repaint();
                            break;
                        case KeyEvent.VK_G:
                            gravity = !gravity;
                            break;
                        case KeyEvent.VK_M:
                            gravityM = !gravityM;
                            break;
                        case KeyEvent.VK_N:
                            uMode = false;
                            nMode = true;
                            big = false;
                            reallyLittle = false;
                            little = false;
                            break;
                       

         

                     
                        case KeyEvent.VK_F:
                            gravityC = !gravityC;
                            break;
                        case KeyEvent.VK_D:
                            dMode = !dMode;
                            break;

                        case KeyEvent.VK_V:
                            mixedMode = !mixedMode;
                            randomizeEffects();

                            break;
                        case KeyEvent.VK_C:
                            col = !col;
                            u.reset();
                            simulation.repaint();
                            break;
                        case KeyEvent.VK_L:

                            weird14 = !weird14;
                            weird = false;
                            weird2 = false;
                            weird4 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird5 = false;
                            weird9 = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            weird21 = false;
                            weird22 = false;
                            weird24 = false;
                            weird25 = false;

                            break;
                        case KeyEvent.VK_J:

                            weird24 = !weird24;
                            weird = false;
                            weird2 = false;
                            weird4 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird5 = false;
                            weird9 = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            weird21 = false;
                            weird22 = false;
                            weird25 = false;

                            break;
                        case KeyEvent.VK_Z:
                            weird15 = !weird15;
                            break;
                        case KeyEvent.VK_X:
                            weird16 = !weird16;
                            break;
                        case KeyEvent.VK_W:
                            white = !white;
                            break;
                        case KeyEvent.VK_1:
                            weird = !weird;
                            weird2 = false;
                            weird4 = false;
                            weird5 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird9 = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            weird21 = false;
                            weird22 = false;
                            weird24 = false;
                            weird25 = false;

                            break;
                        case KeyEvent.VK_2:
                            weird2 = !weird2;
                            weird = false;
                            weird4 = false;
                            weird5 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird9 = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            weird21 = false;
                            weird22 = false;
                            weird24 = false;
                            weird25 = false;

                            break;
                        case KeyEvent.VK_3:
                            weird3 = !weird3;
                            break;
                        case KeyEvent.VK_4:
                            weird4 = !weird4;
                            weird2 = false;
                            weird = false;
                            weird5 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird9 = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            weird21 = false;
                            weird22 = false;
                            weird24 = false;
                            weird25 = false;

                            break;
                        case KeyEvent.VK_5:
                            weird5 = !weird5;
                            weird2 = false;
                            weird4 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird9 = false;
                            weird = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            weird21 = false;
                            weird22 = false;
                            weird24 = false;
                            weird25 = false;

                            break;
                        case KeyEvent.VK_6:
                            weird6 = !weird6;
                            weird2 = false;
                            weird4 = false;
                            weird7 = false;
                            weird8 = false;
                            weird9 = false;
                            weird = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            weird21 = false;
                            weird22 = false;
                            weird24 = false;
                            weird25 = false;

                            break;
                        case KeyEvent.VK_7:
                            weird7 = !weird7;
                            weird2 = false;
                            weird4 = false;
                            weird6 = false;
                            weird8 = false;
                            weird9 = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            weird21 = false;
                            weird22 = false;
                            weird24 = false;
                            weird25 = false;

                            weird = false;
                            break;
                        case KeyEvent.VK_O:
                            weird8 = !weird8;
                            weird = false;
                            weird4 = false;
                            weird6 = false;
                            weird7 = false;
                            weird2 = false;
                            weird5 = false;
                            weird9 = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            weird21 = false;
                            weird22 = false;
                            weird24 = false;
                            weird25 = false;

                            break;
                        case KeyEvent.VK_T:
                            weird9 = !weird9;
                            weird = false;
                            weird2 = false;
                            weird4 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird5 = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            weird21 = false;
                            weird22 = false;
                            weird24 = false;
                            weird25 = false;

                            break;
                        case KeyEvent.VK_Y:
                            weird10 = !weird10;
                            weird = false;
                            weird2 = false;
                            weird4 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird5 = false;
                            weird9 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            weird21 = false;
                            weird22 = false;
                            weird24 = false;
                            weird25 = false;

                            break;
                        case KeyEvent.VK_K:
                            weird11 = !weird11;
                            weird = false;
                            weird2 = false;
                            weird4 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird5 = false;
                            weird9 = false;
                            weird10 = false;
                            weird12 = false;
                            weird13 = false;
                            weird21 = false;
                            weird22 = false;
                            weird24 = false;
                            weird25 = false;

                            break;
                        case KeyEvent.VK_I:
                            weird12 = !weird12;
                            weird = false;
                            weird2 = false;
                            weird4 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird5 = false;
                            weird9 = false;
                            weird10 = false;
                            weird11 = false;
                            weird13 = false;
                            weird21 = false;
                            weird22 = false;
                            weird24 = false;
                            weird25 = false;

                            break;
                        case KeyEvent.VK_A:
                            weird13 = !weird13;
                            weird = false;
                            weird2 = false;
                            weird4 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird5 = false;
                            weird9 = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird21 = false;
                            weird22 = false;
                            weird24 = false;
                            weird25 = false;

                            break;
                        case KeyEvent.VK_B:
                            weird21 = !weird21;
                            weird = false;
                            weird2 = false;
                            weird4 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird5 = false;
                            weird9 = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            weird22 = false;
                            weird24 = false;
                            weird25 = false;

                            break;
                        case KeyEvent.VK_S:
                            weird22 = !weird22;
                            weird = false;
                            weird2 = false;
                            weird4 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird5 = false;
                            weird9 = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            weird21 = false;
                            weird24 = false;
                            weird25 = false;

                            break;
                        case KeyEvent.VK_UP:
                            weird25 = !weird25;
                            weird = false;
                            weird2 = false;
                            weird4 = false;
                            weird6 = false;
                            weird7 = false;
                            weird8 = false;
                            weird5 = false;
                            weird9 = false;
                            weird10 = false;
                            weird11 = false;
                            weird12 = false;
                            weird13 = false;
                            weird21 = false;
                            weird22 = false;

                            weird24 = false;
                            break;
                        case KeyEvent.VK_LEFT:
                            uMode = !uMode;
                            
                            break;
                       
                        case KeyEvent.VK_U:
                            weird17 = !weird17;
                            break;
                        case KeyEvent.VK_SPACE:
                            u.lightReset();
                            simulation.repaint();
                            break;
                        case KeyEvent.VK_Q:
                            reallyLittle = !reallyLittle;
                            break;
                        case KeyEvent.VK_P:
                            isPaused = !isPaused;
                            break;
                    }
                }
            });

            try {
                Thread.sleep(sTime);
            } catch (InterruptedException e1) {
                e1.printStackTrace();
            }

            frame.setFocusable(true);
            frame.requestFocusInWindow();
        });
    }
}
