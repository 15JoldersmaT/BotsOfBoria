package Pack;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Rectangle;

public class AdvancedOpt {

    private Rectangle[] rebelChanceButtons;
    private Rectangle[] landButtons;
    private Rectangle originButton;
    private Rectangle classicButton;
    private Rectangle backButton;

    public AdvancedOpt() {
        initializeButtons();
    }

    private void initializeButtons() {
        // Added more options for rebel chance
        rebelChanceButtons = new Rectangle[10];
        for (int i = 0; i < rebelChanceButtons.length; i++) {
            rebelChanceButtons[i] = new Rectangle(55 + i * 70, 75, 50, 50);
        }

        // Added more options for land size
        landButtons = new Rectangle[7];
        for (int i = 0; i < landButtons.length; i++) {
            landButtons[i] = new Rectangle(55 + i * 70, 175, 50, 50);
        }
        
        originButton = new Rectangle(55, 275, 90, 50);
        classicButton = new Rectangle(155, 275, 90, 50);
        backButton = new Rectangle(50, 350, 600, 50);
    }

    public void buttons(Graphics g) {
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, 20));

        drawSection(g, "Rebel Chance (increase number to decrease chance of rebellion)", 55, 55, rebelChanceButtons, 
            new String[]{"25", "50", "100", "150", "200", "450", "1000", "2000", "5000", "10000"});
        g.setColor(Color.WHITE);

        drawSection(g, "Land Size", 55, 155, landButtons, 
            new String[]{"300", "700", "1000", "1200", "1550", "2100", "2760"});

        drawButton(g, originButton, "Origin", Map.origin);
        drawButton(g, classicButton, "Classic", !Map.origin);

        drawButton(g, backButton, "Back to Main Menu", false); // Added Back to Main Menu button
    }

    private void drawSection(Graphics g, String title, int x, int y, Rectangle[] buttons, String[] labels) {
        g.drawString(title, x, y);
        for (int i = 0; i < buttons.length; i++) {
            boolean selected = false;
            if (title.contains("Rebel Chance")) {
                selected = Map.rebChance == Integer.parseInt(labels[i]);
            } else if (title.contains("Land")) {
                selected = Map.maxLand == Integer.parseInt(labels[i]);
            }
            drawButton(g, buttons[i], labels[i], selected);
        }
    }

    private void drawButton(Graphics g, Rectangle button, String label, boolean selected) {
        if (selected) {
            g.setColor(Color.RED);
        } else {
            g.setColor(Color.WHITE);
        }
        g.fillRoundRect(button.x, button.y, button.width, button.height, 10, 10);
        g.setColor(Color.BLACK);
        g.drawString(label, button.x + 5, button.y + 30);
    }

    public void click() {
        handleRebelChanceClick();
        handleLandClick();
        handleOriginClick();
        handleBackClick();
    }

    private void handleRebelChanceClick() {
        for (int i = 0; i < rebelChanceButtons.length; i++) {
            if (isClicked(rebelChanceButtons[i])) {
                int[] rebelChances = {25, 50, 100, 150, 200, 450, 1000, 2000, 5000, 10000};
                Map.rebChance = rebelChances[i];
                break;
            }
        }
    }

    private void handleLandClick() {
        for (int i = 0; i < landButtons.length; i++) {
            if (isClicked(landButtons[i])) {
                int[] landValues = {300, 700, 1000, 1200, 1550, 2100, 2760};
                Map.maxLand = landValues[i];
                break;
            }
        }
    }

    private void handleOriginClick() {
        if (isClicked(originButton)) {
            Map.origin = true;
        }
        if (isClicked(classicButton)) {
            Map.origin = false;
        }
    }

    private void handleBackClick() {
        if (isClicked(backButton)) {
            Menu.advanced = false;
        }
    }

    private boolean isClicked(Rectangle button) {
        return Fact.xM > button.x && Fact.xM < button.x + button.width && Fact.yM > button.y && Fact.yM < button.y + button.height;
    }
}
