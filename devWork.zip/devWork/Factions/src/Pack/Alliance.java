package Pack;

import java.awt.Color;
import java.util.ArrayList;

public class Alliance {

	private Color ac = new Color(0,0,0);
	
	private ArrayList<Color> nations = new ArrayList<Color>();	
	private ArrayList<Color> Enemies = new ArrayList<Color>();	

	private int tank = 0;
	private int boats = 0;
	private int nukes = 0;
	
	
	public ArrayList<Color> getNations() {
		return nations;
	}
	public void setNations(ArrayList<Color> nations) {
		this.nations = nations;
	}
	public Color getAc() {
		return ac;
	}
	public void setAc(Color ac) {
		this.ac = ac;
	}
	public int getTank() {
		return tank;
	}
	public void setTank(int tank) {
		this.tank = tank;
	}
	public int getBoats() {
		return boats;
	}
	public void setBoats(int boats) {
		this.boats = boats;
	}
	public int getNukes() {
		return nukes;
	}
	public void setNukes(int nukes) {
		this.nukes = nukes;
	}
	public ArrayList<Color> getEnemies() {
		return Enemies;
	}
	public void setEnemies(ArrayList<Color> arrayList) {
		Enemies = arrayList;
	}
	
}
