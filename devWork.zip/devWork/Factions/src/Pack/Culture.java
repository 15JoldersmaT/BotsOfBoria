package Pack;

public class Culture extends Ideology {

	public Culture(String Name) {
		super(Name);
		// TODO Auto-generated constructor stub
	}

}
