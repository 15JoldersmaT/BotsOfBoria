package Pack;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;

public class Fact extends JFrame implements MouseListener, KeyListener {

    Graphics dbg;
    Image db;
    Dimension d = new Dimension(1500, 750);
    Map m = new Map();
    Menu m1 = new Menu();
    Save ss = new Save();
    Load ll = new Load();
    AdvancedOpt ao = new AdvancedOpt();
    public static int xM = 0;
    public static int yM = 0;
    public static int numSave = 1;
    public static int speed = 1;
    public static int year = 0;
    public static boolean showA = false;
    public static boolean showR = false;
    public static boolean showC = false;
    public static boolean showD = false;
    public static boolean paused = false;
    public static boolean lines = true;

    public static int selectedNation;
    public static int selectedFaction;
    public static int selectedF;
    public static boolean edit = false;

    public void paint(Graphics g) {
        db = createImage(d.width, d.height);
        dbg = db.getGraphics();
        paintComponent(dbg);
        g.drawImage(db, 0, 0, null);
    }

    public void paintComponent(Graphics g) {
        if (Menu.gameStarted) {
            m.showMap(dbg);
            m.FactInfo(dbg);
            m.reset(dbg);
            g.setColor(Color.RED);
            g.drawString("Year: " + Fact.year, 40, 40);
            float de = 0;
            int tot = 0;
            for (int counter = 0; counter < Map.tottiles; counter++) {
                if (Map.tileType[counter] == 1) {
                    tot++;
                    de += Map.dTile[counter];
                }
            }
            de /= (tot);
            g.drawString("Average Development: " + de, 440, 40);
        } else {
            if (!m1.advanced) {
                m1.showMenu(dbg);
            } else {
                ao.buttons(dbg);
            }
        }
    }

    public void gameLoop() {
        while (true) {
            if (Menu.gameStarted) {
                if (!Fact.paused) {
                    year++;
                }
                m.gen();
                m.spreadLand();
                m.boats();
                m.moveBoats();
                m.makeTroops();
                m.develope();
                m.attack();
                
                m.makePort();
                m.Rebel();
            } else {
                if (!m1.advanced) {
                    m1.click();
                } else {
                    ao.click();
                }
            }
            repaint();
            try {
                Thread.sleep(speed);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public Fact() {
        this.setSize(700, 650);
        this.setVisible(true);
        this.setBackground(Color.BLACK);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.addMouseListener(this);
        this.addKeyListener(this);
        this.setTitle("Minimperiums 1.4");
        this.setResizable(false);
        gameLoop();
    }

    public static void main(String[] args) {
        new Fact();
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        xM = e.getX();
        yM = e.getY();
    }

    @Override
    public void mouseEntered(MouseEvent arg0) {}

    @Override
    public void mouseExited(MouseEvent arg0) {}

    @Override
    public void mousePressed(MouseEvent arg0) {}

    @Override
    public void mouseReleased(MouseEvent arg0) {}

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_Z) {
            speed += 5;
        }
        if (e.getKeyCode() == KeyEvent.VK_X) {
            speed -= 5;
            if (speed < 1) {
                speed = 1;
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_SPACE) {
            showA = !showA;
        }
        if (e.getKeyCode() == KeyEvent.VK_R) {
            showR = !showR;
            showC = false;
            Map.iShow = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_D) {
            showD = !showD;
        }
        if (e.getKeyCode() == KeyEvent.VK_B) {
            lines = !lines;
        }
        if (e.getKeyCode() == KeyEvent.VK_C) {
            showC = !showC;
            Map.iShow = false;
            showR = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_N) {
            Map.ideoSelect = null;
            Fact.xM = -100;
        } else if (e.getKeyCode() == KeyEvent.VK_I) {
            showR = false;
            Map.iShow = !Map.iShow;
            showC = false;
        } else if (e.getKeyCode() == KeyEvent.VK_P) {
            paused = !paused;
        } else if (e.getKeyCode() == KeyEvent.VK_S) {
            ss.makeSave();
        } else if (e.getKeyCode() == KeyEvent.VK_L) {
            ll.loadSave();
        } else if (e.getKeyCode() == KeyEvent.VK_E) {
            edit = !edit;
        }

        if (e.getKeyCode() == KeyEvent.VK_0) {
            numSave = 0;
        } else if (e.getKeyCode() == KeyEvent.VK_1) {
            numSave = 1;
        } else if (e.getKeyCode() == KeyEvent.VK_2) {
            numSave = 2;
        } else if (e.getKeyCode() == KeyEvent.VK_3) {
            numSave = 3;
        } else if (e.getKeyCode() == KeyEvent.VK_4) {
            numSave = 4;
        } else if (e.getKeyCode() == KeyEvent.VK_5) {
            numSave = 5;
        }
    }

    @Override
    public void keyTyped(KeyEvent arg0) {}
}
