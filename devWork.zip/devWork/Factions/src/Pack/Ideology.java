package Pack;

import java.awt.Color;

public class Ideology {

	private String name; 
	private Color c;
	public Ideology(String Name){
		setName(Name);
	}
	public Color getC() {
		return c;
	}
	public void setC(Color c) {
		this.c = c;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
