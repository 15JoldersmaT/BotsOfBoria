package Pack;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class Load {

	Random rand = new Random();
	public Load(){
		
	}
	public String randomName(){
		String name;
		String a;
		String b; 
		String c;
		String d;
		
		int A = rand.nextInt(14);
		int B = rand.nextInt(6);
		int C= rand.nextInt(5);
		int D = rand.nextInt(7);
		
		if(A == 1){
			a = "Pre";
		}else if(A==2){
			a = "A";
		}else if(A==3){
			a = "Bre";
		}else if(A==4){
			a = "Ti";
		}else if(A==5){
			a = "K";
		}else if(A==6){
			a = "B";
		}else if(A==7){
			a = "D";
		}else if(A==8){
			a = "E";
		}else if(A==9){
			a = "O";
		}else if(A==10){
			a = "L";
		}else if(A==11){
			a = "N";
		}else if(A==12){
			a = "V";
		}else if(A==13){
			a = "W";
		}else{
			a = "Ci";
		}

		if(B == 1){
			b = "ok";
		}else if(B==2){
			b ="y";
		}else if(B==3){
			b ="e";
		}else if(B==4){
			b ="a";
		}else if(B==5){
			b ="u";
		}else{
			b="ag";
		}
		
		if(C == 1){
			c = "o";
		}else if(C==2){
			c = "il";
		}else if(C==3){
			c = "u";
		}else if(C==4){
			c = "e";
		}else{
			c = "re";
		}
		
		if(D == 1){
			d = "";
		}else if(D==2){
			d = "azle";
		}else if(D==3){
			d = "y";
		}else if(D==4){
			d = "e";
		}else if(D==5){
			d = "";
		}else if(D==6){
			d = "o";
		}else{
			d ="ohi";
		}
		name = a+b+c+d;
		return name;
	}
	public void loadSave() {
		for(int counter = 0;counter<Map.tottiles;counter++){
			
			try {
				
				BufferedReader br = new BufferedReader(new FileReader("C:\\Warz\\Type\\" +Integer.toString(Fact.numSave)+"\\" + counter+".txt"));
		
				StringBuilder sb = new StringBuilder();
				
		
		        
				String line = br.readLine();
	


		        while (line != null) {
		        	sb.append(line);
		            sb.append(System.lineSeparator());
		            line = br.readLine();
		        }
	
		        	String everything = sb.toString();
		        

		        	if(everything.contains("1")){
		        		
		        		Map.tileType[counter] = 1;
		        		if(Map.tileType[counter] == 1){
		        		
		  
		        		
		        		}
		        	}else{
		        		Map.boated[counter] = false;
		        		Map.cTile[counter] = null;
		        		Map.tileType[counter] = 0;
		        	}
		        	
		        
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		for(int counter =0;counter<Map.tottiles;counter++){
		try {
			
			BufferedReader br = new BufferedReader(new FileReader("C:\\Warz\\Type\\" +Integer.toString(Fact.numSave)+"\\" + counter+".txt"));
		//	BufferedReader brR = new BufferedReader(new FileReader("C:\\Warz\\Color\\" +Integer.toString(Fact.numSave)+"\\Red\\" + counter+".txt"));
			
			//BufferedReader brBoat = new BufferedReader(new FileReader("C:\\Warz\\Boat\\" +Integer.toString(Fact.numSave)+"\\" + counter+".txt"));

			
			StringBuilder sb = new StringBuilder();
			StringBuilder sbR = new StringBuilder();


			
	        
			String line = br.readLine();
			//String lineR = brR.readLine();

			//Scanner scannerR = new Scanner(new File("C:\\Warz\\Color\\" +Integer.toString(Fact.numSave)+"\\Red\\" + counter+".txt"));
			//Scanner scannerG = new Scanner(new File("C:\\Warz\\Color\\" +Integer.toString(Fact.numSave)+"\\Green\\" + counter+".txt"));
			//Scanner scannerB = new Scanner(new File("C:\\Warz\\Color\\" +Integer.toString(Fact.numSave)+"\\Blue\\" + counter+".txt"));

			int r = 0;
			int g = 0;
			int b = 0;
			/**
			while(scannerR.hasNextInt()){
				r = scannerR.nextInt();
			}
			while(scannerG.hasNextInt()){
				g = scannerG.nextInt();
			}
			while(scannerB.hasNextInt()){
				b = scannerB.nextInt();
			}
			*/

	        while (line != null) {
	        	sb.append(line);
	        	//sbR.append(lineR);
	            sb.append(System.lineSeparator());
	            sbR.append(System.lineSeparator());
	          //  lineR = brR.readLine();
	            line = br.readLine();
	        }

	        	String everything = sb.toString();
	        	String everythingR = sbR.toString();
	        	everythingR.trim();
	        	System.out.println(everythingR);
	        	
	        
	        	
	        	
	        	Map.cTile[counter] = new Color(r, b,g);
	        	
	        	if(everything.contains("1")){
	        		
	        		Map.tileType[counter] = 1;
	        		if(Map.tileType[counter] == 1){
	        		int t = rand.nextInt(20);
	        		if(t == 1){
	        			Map.Base[counter] = true;
	        		}
	        		Map.cTile[counter] = new Color(rand.nextInt(255),rand.nextInt(255),rand.nextInt(255));
					Alliance a2 = new Alliance();
					a2.setAc(new Color(rand.nextInt(255),rand.nextInt(255),rand.nextInt(255)));
					a2.setTank(5);
					Map.aTile[counter] = a2;
					int ide = rand.nextInt(2);
					Map m= new Map();
					Ideology itz = new Ideology(randomName());
					itz.setC(new Color(rand.nextInt(255),rand.nextInt(255),rand.nextInt(255)));
					Map.knownI.add(itz);
					Map.iTile[counter] = itz;
					
					//
					Religion rtz = new Religion(randomName());
					System.out.println(rtz.getName());
					rtz.setC(new Color(rand.nextInt(255),rand.nextInt(255),rand.nextInt(255)));
					Map.knownR.add(rtz);
					Map.rTile[counter] = rtz;
					//
					Culture cu = new Culture(randomName());
					System.out.println(rtz.getName());
					cu.setC(new Color(rand.nextInt(255),rand.nextInt(255),rand.nextInt(255)));
					Map.knowC.add(cu);
					Map.cuTile[counter] = cu;
					Map.countryName[counter] = m.randomName();
					Map.nuclear[counter] = false;
					Map.capital[counter] = true;
					Map.countryAge[counter] = 0;
	        		
	        		}
	        	}else{
	        		Map.boated[counter] = false;
	        		Map.cTile[counter] = null;
	        		Map.tileType[counter] = 0;
	        	}
	        	
	        	
	        
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	
	}
	}
}
