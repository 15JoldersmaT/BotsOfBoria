package Pack;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Random;





public class Map {

	public static int tottiles = 2760;
	public static int x = 50;
	public static int y = 50;
	public static int[] xtile = new int[tottiles];
	public static int[] ytile = new int[tottiles];
	public static Color[] cTile = new Color[tottiles];
	public static boolean[] Base = new boolean[tottiles];
	public static boolean origin = false;
	public static boolean civFounded =false;
	public static ArrayList<Alliance> a = new ArrayList<Alliance>();
	public static int gainNuke = 36000000;
	
	public static int[] tileType = new int[tottiles];
	public static String[] countyName = new String[tottiles];
	public static String[] countryName = new String[tottiles];
	public static int[] countryAge = new int[tottiles];

	public static boolean[] nuclear = new boolean[tottiles];
	public static boolean[] fallout = new boolean[tottiles];
	
	public static boolean[] boated = new boolean[tottiles];
	
	public static boolean[] capital = new boolean[tottiles];

	public static int nukeChance = 300;
	public static Alliance[] aTile = new Alliance[tottiles];
	Ideology facism = new Ideology("Facism");
	Ideology theocracy = new Ideology("Theocracy");
	Ideology democracy = new Ideology("Democracy");
	Ideology communism = new Ideology("Communism");
	Ideology monarchy = new Ideology("Monarchy");

	public static Ideology[] iTile = new Ideology[tottiles];
	public static Religion[] rTile = new Religion[tottiles];
	public static Culture[] cuTile =new Culture[tottiles];
	public static Alliance[] eTile = new Alliance[tottiles];
	public static int[] dTile = new int[tottiles];

	public static ArrayList<Ideology> knownI = new ArrayList<Ideology>();
	public static ArrayList<Religion> knownR = new ArrayList<Religion>();
	public static ArrayList<Culture> knowC = new ArrayList<Culture>();
	
	public static int ts = 10;
	public static int land = 0;
	public static int maxLand = 400;
	public static boolean started = false;
	public static int ports = 0;
	public static boolean ported = false;
	public static int rebChance = 100;
	public static int maxPorts = 20;
	public static boolean iShow = false;
	public static String ideoSelect;
	Random rand = new Random();
	
	public Map(){
		
	}
	
	public void gen(){
		
		if(started == false){
			

			if(Menu.large == true){
				tottiles = tottiles * 4;
				tottiles -= 110;
				 xtile = new int[tottiles];
				 ytile = new int[tottiles];
				 cTile = new Color[tottiles];
				 tileType = new int[tottiles];
				 boated = new boolean[tottiles];
				 maxLand *= 4;
				
			}
			for(int counter = 0;counter<tottiles;counter++){
				nuclear[counter] = false;
				dTile[counter] = 7;
				countyName[counter] = randomName();
				countryName[counter] = randomName();


				int t = 1;
				if(Menu.arch == true){
					if(Menu.large == true){
						t = rand.nextInt(100);
						maxPorts = 200;
					}else{
				t = rand.nextInt(25);
				maxPorts = 50;
					}
				}else{
					if(Menu.large == true){
						t = rand.nextInt(1000);
					}else{
				t = rand.nextInt(250);
					}
				}
				xtile[counter] = x;
				ytile[counter] = y;
			
				x += ts;
				if(Menu.large == false){
				if(x >= 650){
					x = 50;
					y+= ts;
				}
				}else{
					if(x >= 1300){
						x = 50;
						y+= ts;
					}
				}
				if(t == 1){
					Ideology itz = new Ideology(randomName());
					System.out.println(itz.getName());
					itz.setC(new Color(rand.nextInt(255),rand.nextInt(255),rand.nextInt(255)));
					knownI.add(itz);
					iTile[counter] = itz;
					
					//
					Religion rtz = new Religion(randomName());
					System.out.println(rtz.getName());
					rtz.setC(new Color(rand.nextInt(255),rand.nextInt(255),rand.nextInt(255)));
					knownR.add(rtz);
					rTile[counter] = rtz;
					//
					countyName[counter] =randomName();
					countryAge[counter] = 0;
					countryName[counter] = randomName();
					nuclear[counter] = false;
					tileType[counter] = 1;
					Base[counter] = true;
					capital[counter] = true;
					land++;
					if(origin == true){
					if( civFounded == false){
					int spawnChance = rand.nextInt(5000);
					if(spawnChance == 1){
						civFounded = true;
						Base[counter] = true;
						capital[counter] = true;
						nuclear[counter] = false;
						cTile[counter] = new Color(rand.nextInt(254), rand.nextInt(254),rand.nextInt(254));
						Alliance a4 = new Alliance();
						a4.setAc(cTile[counter]);
						Alliance a3 = new Alliance();
						a3.setAc(cTile[counter]);
						aTile[counter] = a3;
						eTile[counter] = a4;

					}else{
						civFounded = true;
						Base[counter] = true;
						capital[counter] = true;
						nuclear[counter] = false;
						cTile[counter] = new Color(rand.nextInt(254), rand.nextInt(254),rand.nextInt(254));
						Alliance a4 = new Alliance();
						a4.setAc(cTile[counter]);
						Alliance a3 = new Alliance();
						a3.setAc(cTile[counter]);
						aTile[counter] = a3;
						eTile[counter] = a4;
						
					}
					}else{
						civFounded = true;
						Base[counter] = true;
						capital[counter] = true;
						nuclear[counter] = false;
						cTile[counter] = new Color(rand.nextInt(254), rand.nextInt(254),rand.nextInt(254));
						Alliance a4 = new Alliance();
						a4.setAc(cTile[counter]);
						Alliance a3 = new Alliance();
						a3.setAc(cTile[counter]);
						aTile[counter] = a3;
						eTile[counter] = a4;
					}
					}else{
						civFounded = true;
						Base[counter] = true;
						capital[counter] = true;
						nuclear[counter] = false;
						cTile[counter] = new Color(rand.nextInt(254), rand.nextInt(254),rand.nextInt(254));
						Alliance a4 = new Alliance();
						a4.setAc(cTile[counter]);
						Alliance a3 = new Alliance();
						a3.setAc(cTile[counter]);
						aTile[counter] = a3;
						eTile[counter] = a4;
					}
					
				
				}else{
					countryName[counter] = "";

					countyName[counter] = "";
					
					tileType[counter] = 0;
				}

			
				
			}
	
			started = true;
		}
	}
	// Shuffle array utility method
	private int[] getShuffledIndices() {
	    int[] indices = new int[tottiles];
	    for (int i = 0; i < tottiles; i++) {
	        indices[i] = i;
	    }
	    // Shuffle the array
	    for (int i = tottiles - 1; i > 0; i--) {
	        int index = rand.nextInt(i + 1);
	        int temp = indices[index];
	        indices[index] = indices[i];
	        indices[i] = temp;
	    }
	    return indices;
	}
	public String randomName(){
	    String[] prefixes = {"An", "Bel", "Cal", "Dar", "El", "Fen", "Gor", "Ir", "Kel", "Lor", "Mar", "Nor", "Par", "Sar", "Tor", "Vor", "Xan", "Yor", "Zan"};
	    String[] vowels = {"a", "e", "i", "o", "u"};
	    String[] consonants = {"b", "c", "d", "f", "g", "h", "k", "l", "m", "n", "r", "s", "t", "v", "z"};
	    String[] suffixes = {"dor", "ia", "on", "eth", "ar", "is", "en", "al", "im", "os"};

	    Random rand = new Random();

	    // Generate random number of syllables (2 to 3)
	    int syllables = rand.nextInt(2) + 2;
	    StringBuilder name = new StringBuilder();

	    // Prefix
	    name.append(prefixes[rand.nextInt(prefixes.length)]);

	    // Add random syllables based on consonant and vowel alternation
	    for (int i = 0; i < syllables - 1; i++) {
	        name.append(consonants[rand.nextInt(consonants.length)]);
	        name.append(vowels[rand.nextInt(vowels.length)]);
	    }

	    // Add a random suffix
	    name.append(suffixes[rand.nextInt(suffixes.length)]);

	    // Capitalize the first letter
	    return name.toString();
	}

	public void showMap(Graphics g){
		try{
			if(Fact.showD == true){
				for(int counter = 0;counter<tottiles;counter++){
					if(tileType[counter] == 0){
						g.setColor(Color.BLUE);
						g.fillRect(xtile[counter], ytile[counter], ts, ts);

					}else{
						if(dTile[counter] == 7){
							g.setColor(new Color(25,50,25));
						}else if(dTile[counter] == 6){
							g.setColor(new Color(35,75,35));
						}else if(dTile[counter] == 5){
							g.setColor(new Color(45,100,45));
						}else if(dTile[counter] == 4){
							g.setColor(new Color(55,125,55));
						}else if(dTile[counter] == 3){
							g.setColor(new Color(65,150,65));
						}else{
							g.setColor(new Color(75,175,75));
						}
						g.fillRect(xtile[counter], ytile[counter], ts, ts);
						if(Base[counter] == true){
							g.setColor(Color.ORANGE);
							g.drawOval(xtile[counter], ytile[counter], ts, ts);
						}

					}
				}
				if(Fact.lines == true){
				for(int counter = 0;counter<tottiles;counter++){
					for(int ha = 0;ha<tottiles;ha++){
						double dist = 0;
						int sideA = 0;
						int sideB = 0;
						
					
						sideA = xtile[counter] - Map.xtile[ha];
						sideB = ytile[counter] - Map.ytile[ha];
						
						if(sideA <0){
							sideA *= -1;
						}
						if(sideA <0){
							sideA *= -1;
						}
						
						dist = Math.sqrt((sideA * sideA) + (sideB * sideB));
						if(dist <= ts && cTile[counter] != cTile[ha] && tileType[counter] == 1 ){
							g.setColor(Color.BLACK);

							if(xtile[ha] < xtile[counter] && ytile[ha] == ytile[counter] ){
								g.drawLine(xtile[ha] + ts , ytile[ha],xtile[ha] + ts , ytile[ha] + ts);
							}if(xtile[ha] > xtile[counter] && ytile[ha] == ytile[counter]){
								g.drawLine(xtile[ha] , ytile[ha],xtile[ha], ytile[ha] + ts);
							}
							
							if(ytile[ha] < ytile[counter] && xtile[ha] == xtile[counter] ){
								g.drawLine(xtile[ha] , ytile[ha] + ts,xtile[ha] + ts , ytile[ha] + ts);
							}if(ytile[ha] > ytile[counter] && xtile[ha] == xtile[counter]){
								g.drawLine(xtile[ha] , ytile[ha],xtile[ha] +ts, ytile[ha] );
							}
						}
					} 
				}
				}
			}else{
			
			if(Fact.showC == true){
				g.setColor(Color.CYAN);
				g.drawString("Cultures", 250, 40);
				for(int zz = 0;zz<tottiles;zz++){
					if(cuTile[zz] == null && tileType[zz] == 1){
						Culture itz = new Culture(randomName());
						itz.setC(new Color(255,255,255));
						knowC.add(itz);
						cuTile[zz] = itz;
						g.setColor(Color.GREEN);
					}
					if(tileType[zz] == 1){
						
					g.setColor(cuTile[zz].getC());
					g.fillRect(xtile[zz], ytile[zz], ts, ts);
					
					if(Base[zz] == true){
						int redz = 255 -cuTile[zz].getC().getRed();
						int bz = 255 -cuTile[zz].getC().getBlue();

						int gz = 255 -cuTile[zz].getC().getGreen();

						Color op = new Color(redz,gz,bz);
						g.setColor(op);
							g.drawOval(xtile[zz], ytile[zz], ts - 3, ts - 3);
						
							
						g.fillOval(xtile[zz], ytile[zz], ts - 3, ts - 3);
						g.setColor(Color.WHITE);
					}
				
						}
					else{
						g.setColor(Color.CYAN);
						g.fillRect(xtile[zz], ytile[zz], ts, ts);
						if(boated[zz] == true){
							if(cuTile[zz].getName() == Map.ideoSelect){
								g.setColor(Color.WHITE);
								g.fillOval(xtile[zz], ytile[zz], ts, ts);
							}else{
								g.setColor(Color.BLACK);
								g.fillOval(xtile[zz], ytile[zz], ts, ts);
							}
						}

					}
				
				
			}
			for(int counter = 0;counter<tottiles;counter++){
				if(cTile[counter] != Color.GREEN){
				if( tileType[counter] == 1){
					if(iTile[counter] != null){
					g.setColor(cuTile[counter].getC());
					g.fillRect(xtile[counter], ytile[counter], 5, 5);
					}
				}else if(tileType[counter] == 0){
					g.setColor(Color.BLACK);
					g.drawRect(xtile[counter], ytile[counter], 5, 5);
					g.setColor(Color.CYAN);
				}
				else if(tileType[counter] == 2){
					g.setColor(Color.ORANGE);
					g.fillRect(xtile[counter], ytile[counter], 5, 5);
				}
				g.fillRect(xtile[counter], ytile[counter], ts, ts);
				if(tileType[counter] == 0){
					if(rTile[counter] != null){
					g.setColor(cuTile[counter].getC());
					}
					g.fillOval(xtile[counter], ytile[counter], ts, ts);
				}
				if(Base[counter] == true){
					int redz = 255 -cuTile[counter].getC().getRed();
					int bz = 255 -cuTile[counter].getC().getBlue();

					int gz = 255 -cuTile[counter].getC().getGreen();

					Color op = new Color(redz,gz,bz);
					g.setColor(op);
						g.drawOval(xtile[counter], ytile[counter], ts - 3, ts - 3);
					
						
					g.fillOval(xtile[counter], ytile[counter], ts - 3, ts - 3);
					g.setColor(Color.WHITE);
				}

			}
			}
			
		
		}else
			if(Fact.showR == true){
				g.setColor(Color.ORANGE);
				g.drawString("Religions", 250, 40);
				for(int zz = 0;zz<tottiles;zz++){
					if(rTile[zz] == null && tileType[zz] == 1){
						Religion itz = new Religion(randomName());
						itz.setC(new Color(255,255,255));
						knownR.add(itz);
						rTile[zz] = itz;
						g.setColor(Color.GREEN);
					}
					if(tileType[zz] == 1){
						
					g.setColor(rTile[zz].getC());
					g.fillRect(xtile[zz], ytile[zz], ts, ts);
					
					if(Base[zz] == true){
						int redz = 255 -rTile[zz].getC().getRed();
						int bz = 255 -rTile[zz].getC().getBlue();

						int gz = 255 -rTile[zz].getC().getGreen();

						Color op = new Color(redz,gz,bz);
						g.setColor(op);
							g.drawOval(xtile[zz], ytile[zz], ts - 3, ts - 3);
						
							
						g.fillOval(xtile[zz], ytile[zz], ts - 3, ts - 3);
						g.setColor(Color.WHITE);
					}
				
						}
					else{
						g.setColor(Color.CYAN);
						g.fillRect(xtile[zz], ytile[zz], ts, ts);
						if(boated[zz] == true){
							if(rTile[zz].getName() == Map.ideoSelect){
								g.setColor(Color.WHITE);
								g.fillOval(xtile[zz], ytile[zz], ts, ts);
							}else{
								g.setColor(Color.BLACK);
								g.fillOval(xtile[zz], ytile[zz], ts, ts);
							}
						}

					}
				
				
			}
			for(int counter = 0;counter<tottiles;counter++){
				if(cTile[counter] != Color.GREEN){
				if( tileType[counter] == 1){
					if(iTile[counter] != null){
					g.setColor(rTile[counter].getC());
					g.fillRect(xtile[counter], ytile[counter], 5, 5);
					}
				}else if(tileType[counter] == 0){
					g.setColor(Color.BLACK);
					g.drawRect(xtile[counter], ytile[counter], 5, 5);
					g.setColor(Color.CYAN);
				}
				else if(tileType[counter] == 2){
					g.setColor(Color.ORANGE);
					g.fillRect(xtile[counter], ytile[counter], 5, 5);
				}
				g.fillRect(xtile[counter], ytile[counter], ts, ts);
				if(tileType[counter] == 0){
					if(rTile[counter] != null){
					g.setColor(rTile[counter].getC());
					}
					g.fillOval(xtile[counter], ytile[counter], ts, ts);
				}
				if(Base[counter] == true){
					int redz = 255 -rTile[counter].getC().getRed();
					int bz = 255 -rTile[counter].getC().getBlue();

					int gz = 255 -rTile[counter].getC().getGreen();

					Color op = new Color(redz,gz,bz);
					g.setColor(op);
						g.drawOval(xtile[counter], ytile[counter], ts - 3, ts - 3);
					
						
					g.fillOval(xtile[counter], ytile[counter], ts - 3, ts - 3);
					g.setColor(Color.WHITE);
				}

			}
			}
			
		
		}
			else if(iShow == true){
				g.setColor(Color.GREEN);
				g.drawString("Ideologies", 250, 40);

				for(int zz = 0;zz<tottiles;zz++){
					if(iTile[zz] == null && tileType[zz] == 1){
						Ideology itz = new Ideology(randomName());
						itz.setC(new Color(255,255,255));
						knownI.add(itz);
						iTile[zz] = itz;
						g.setColor(Color.GREEN);
					}
					if(tileType[zz] == 1){
						
					g.setColor(iTile[zz].getC());
					g.fillRect(xtile[zz], ytile[zz], ts, ts);
					
					if(Base[zz] == true){
						int redz = 255 -iTile[zz].getC().getRed();
						int bz = 255 -iTile[zz].getC().getBlue();

						int gz = 255 -iTile[zz].getC().getGreen();

						Color op = new Color(redz,gz,bz);
						g.setColor(op);
							g.drawOval(xtile[zz], ytile[zz], ts - 3, ts - 3);
						
							
						g.fillOval(xtile[zz], ytile[zz], ts - 3, ts - 3);
						g.setColor(Color.WHITE);
					}
				
						}
					else{
						g.setColor(Color.CYAN);
						g.fillRect(xtile[zz], ytile[zz], ts, ts);
						if(boated[zz] == true){
							if(iTile[zz].getName() == Map.ideoSelect){
								g.setColor(Color.WHITE);
								g.fillOval(xtile[zz], ytile[zz], ts, ts);
							}else{
								g.setColor(Color.BLACK);
								g.fillOval(xtile[zz], ytile[zz], ts, ts);
							}
						}

					}
				
				
			}
			for(int counter = 0;counter<tottiles;counter++){
				if(cTile[counter] != Color.GREEN){
				if( tileType[counter] == 1){
					if(iTile[counter] != null){
					g.setColor(iTile[counter].getC());
					g.fillRect(xtile[counter], ytile[counter], 5, 5);
					}
				}else if(tileType[counter] == 0){
					g.setColor(Color.BLACK);
					g.drawRect(xtile[counter], ytile[counter], 5, 5);
					g.setColor(Color.CYAN);
				}
				else if(tileType[counter] == 2){
					g.setColor(Color.ORANGE);
					g.fillRect(xtile[counter], ytile[counter], 5, 5);
				}
				g.fillRect(xtile[counter], ytile[counter], ts, ts);
				if(tileType[counter] == 0){
					if(iTile[counter] != null){
					g.setColor(iTile[counter].getC());
					}
					g.fillOval(xtile[counter], ytile[counter], ts, ts);
				}
				if(Base[counter] == true){
					int redz = 255 -iTile[counter].getC().getRed();
					int bz = 255 -iTile[counter].getC().getBlue();

					int gz = 255 -iTile[counter].getC().getGreen();

					Color op = new Color(redz,gz,bz);
					g.setColor(op);
						g.drawOval(xtile[counter], ytile[counter], ts - 3, ts - 3);
					
						
					g.fillOval(xtile[counter], ytile[counter], ts - 3, ts - 3);
					g.setColor(Color.WHITE);
				}

			}
			}
			
		
		}else{
		if(Fact.showA == true){
			g.setColor(Color.RED);
			g.drawString("Factions", 35, 45);
		}
		for(int counter = 0;counter<tottiles;counter++){
		
			if(aTile[counter] == null){
				Alliance a5 = new Alliance();
				a5.setAc(new Color(rand.nextInt(254) + 1, rand.nextInt(254) + 1, rand.nextInt(254) + 1));
			//	aTile[counter] = a5;
			}
			Color c;
			Color c1;
			if(cTile[counter] != null && aTile[counter] != null){
			 c = new Color(255 - cTile[counter].getRed(), 255 - cTile[counter].getGreen(), 255 -cTile[counter].getBlue());
			 c1 = new Color(255 - aTile[counter].getAc().getRed(), 255 - aTile[counter].getAc().getGreen(), 255 -aTile[counter].getAc().getBlue());
			}else{
				c = Color.BLACK;
				c1 = Color.BLACK;
			}
			if(tileType[counter] != 0){
				if(Fact.showA == false){
				g.setColor(cTile[counter]);
				}else{
					if(aTile[counter] != null){
					g.setColor(aTile[counter].getAc());
					}
				}
				g.fillRect(xtile[counter], ytile[counter], ts, ts);
				if(Base[counter] == true){
					if(Fact.showA == false){
					g.setColor(c);
					}else{
						g.setColor(c1);
					}
					g.fillOval(xtile[counter], ytile[counter], ts -3, ts-3);
					if(capital[counter] == true){
					

					}
				}
		
			
			}
			
			else{
				
				g.setColor(Color.CYAN);
				g.fillRect(xtile[counter], ytile[counter],ts,ts);
				g.setColor(Color.BLACK);
				//g.drawRect(xtile[counter], ytile[counter], ts, ts);
				if(boated[counter] == true){
					if(Fact.showA == false){
					g.setColor(cTile[counter]);
					g.fillOval(xtile[counter], ytile[counter], ts -1, ts - 1);
					g.setColor(c);
					g.drawOval(xtile[counter], ytile[counter], ts - 1, ts -1);
					}else{
						if(aTile[counter] != null){
					g.setColor(aTile[counter].getAc());
					g.fillOval(xtile[counter], ytile[counter], ts -1, ts - 1);
					g.setColor(c1);
					g.drawOval(xtile[counter], ytile[counter], ts - 1, ts -1);
						}
					}
				}else{
					aTile[counter] = null;
				}
			}
		}
		}
		for(int counter = 0;counter<tottiles;counter++){
			for(int ha = 0;ha<tottiles;ha++){
				double dist = 0;
				int sideA = 0;
				int sideB = 0;
				
			
				sideA = xtile[counter] - Map.xtile[ha];
				sideB = ytile[counter] - Map.ytile[ha];
				
				if(sideA <0){
					sideA *= -1;
				}
				if(sideA <0){
					sideA *= -1;
				}
				
				dist = Math.sqrt((sideA * sideA) + (sideB * sideB));
				if(dist <= ts && cTile[counter] != cTile[ha] && tileType[counter] == 1 ){
					g.setColor(Color.BLACK);

					if(xtile[ha] < xtile[counter] && ytile[ha] == ytile[counter] ){
						g.drawLine(xtile[ha] + ts , ytile[ha],xtile[ha] + ts , ytile[ha] + ts);
					}if(xtile[ha] > xtile[counter] && ytile[ha] == ytile[counter]){
						g.drawLine(xtile[ha] , ytile[ha],xtile[ha], ytile[ha] + ts);
					}
					
					if(ytile[ha] < ytile[counter] && xtile[ha] == xtile[counter] ){
						g.drawLine(xtile[ha] , ytile[ha] + ts,xtile[ha] + ts , ytile[ha] + ts);
					}if(ytile[ha] > ytile[counter] && xtile[ha] == xtile[counter]){
						g.drawLine(xtile[ha] , ytile[ha],xtile[ha] +ts, ytile[ha] );
					}
				}
			} 
		}
		}
		}catch(Exception e){
		
		}
		
		}
	public void spreadLand(){
		if(land < maxLand){
			int[] shuffledIndices = getShuffledIndices();
            for (int counter : shuffledIndices) {
                for (int count : shuffledIndices) {
				if(land < maxLand){
				
				if(tileType[counter] == 0 && tileType[count] == 1){
				if(xtile[counter] > xtile[count] - ts *2 && xtile[counter] < xtile[count] +  ts *2 && ytile[counter] > ytile[count] - ts * 2 && ytile[counter] < ytile[count] +  ts *2 ){
			

					int t = rand.nextInt(15);
					countyName[counter] = randomName();
					countryName[counter] = randomName();
					nuclear[counter] = false;
					countryAge[counter] = 0;


					
					if(t == 1){
						int makeBase = rand.nextInt(50);
						tileType[counter] = 1;
						Ideology itz = new Ideology(randomName());
						itz.setC(new Color(rand.nextInt(255),rand.nextInt(255),rand.nextInt(255)));
						knownI.add(itz);
						iTile[counter] = itz;
						
						//
						Religion rtz = new Religion(randomName());
						System.out.println(rtz.getName());
						rtz.setC(new Color(rand.nextInt(255),rand.nextInt(255),rand.nextInt(255)));
						knownR.add(rtz);
						rTile[counter] = rtz;
						//
						Culture cu = new Culture(randomName());
						System.out.println(rtz.getName());
						cu.setC(new Color(rand.nextInt(255),rand.nextInt(255),rand.nextInt(255)));
						knowC.add(cu);
						cuTile[counter] = cu;
						
						if(makeBase == 1){
							Base[counter] = true;
							capital[counter] = true;
						}
						land++;
						if(origin == true){
							int spawnChance = rand.nextInt(300);
							if(spawnChance == 1 && civFounded == false){
						cTile[counter] =  new Color(rand.nextInt(254) + 1, rand.nextInt(254) + 1, rand.nextInt(254) + 1);
						Alliance a4 = new Alliance();
						a4.setAc(new Color(rand.nextInt(254) + 1, rand.nextInt(254) + 1, rand.nextInt(254) + 1));
						
						Alliance a6 = new Alliance();
							a6.setAc(new Color(rand.nextInt(254) + 1, rand.nextInt(254) + 1, rand.nextInt(254) + 1));
							eTile[counter] = a6;;
							civFounded = true;
							Base[counter] = true;
						aTile[counter] = a4;
							}else{
								cTile[counter] =  Color.GREEN;
								Alliance a4 = new Alliance();
								a4.setAc(new Color(0,255,0));
								aTile[counter] = a4;
								
								Alliance a6 = new Alliance();
								a6.setAc(new Color(0,255, 0));
								eTile[counter] = a6;
							}
						}else{
							cTile[counter] =  new Color(rand.nextInt(254) + 1, rand.nextInt(254) + 1, rand.nextInt(254) + 1);
							
							Alliance a4 = new Alliance();
							a4.setAc(new Color(rand.nextInt(254) + 1, rand.nextInt(254) + 1, rand.nextInt(254) + 1));
							aTile[counter] = a4;
							
							Alliance a6 = new Alliance();
							a6.setAc(new Color(rand.nextInt(254) + 1, rand.nextInt(254) + 1, rand.nextInt(254) + 1));
							eTile[counter] = a6;
						}

					}
				}
				}
				}
				
			}
		}	
		}
	}
	
	public void attack(){
		try{
		if(land >= maxLand && Fact.paused == false){
		for(int counter = 0;counter<tottiles;counter++){
			
			for(int count = 0;count<tottiles;count++){
				
			
				
				if(cTile[counter] == cTile[count]){
					aTile[counter] = aTile[count];
					iTile[counter] = iTile[count];
					rTile[counter] = rTile[count];
					cuTile[counter] = cuTile[count];

				}
				if(tileType[counter] == 1 && tileType[count] == 1 && cTile[count] != Color.BLACK   && cTile[count] != Color.GREEN){ 
				if(xtile[counter] > xtile[count] - ts *2 && xtile[counter] < xtile[count] +  ts *2 && ytile[counter] > ytile[count] - ts * 2 && ytile[counter] < ytile[count] +  ts *2 ){

					int t = rand.nextInt(25);
					if(Map.aTile[counter] != null){
						int them = 0;
						int us = 0;
				
						/*
						for(int sides = 0;sides<Map.tottiles;sides++){
							if(Map.cTile[sides] == Map.cTile[counter]){
								them++;
							}
							if(Map.cTile[sides] == Map.cTile[count]){
								us++;
							}
							
						}
						
						int surrender = rand.nextInt(16000);
						if(them > (us * 4) && surrender == 1 && aTile[counter] != aTile[count] && cTile[counter] != Color.GREEN && cTile[count] != Color.GREEN){
							for(int c2 = 0;c2<Map.tottiles;c2++){
								if(Map.cTile[c2] == Map.cTile[count]){
								Map.cTile[c2] = Map.cTile[counter];
								Map.aTile[c2] = Map.aTile[counter];
									Map.iTile[c2] = Map.iTile[counter];
								}
							
						
							}
						}
						*/
						int yy = rand.nextInt(9000);
						if(yy==1 && aTile[count].getTank() == 0) {
							//aTile[count].setTank(1);
						}
						if(t == 1 && aTile[counter].getTank() >= 1 && aTile[counter] != aTile[count]){
								aTile[count].setTank(aTile[count].getTank() -1);
								if(aTile[count].getTank() < 0){
									aTile[count].setTank(0);
								}
								iTile[counter] = iTile[count];
								aTile[counter] = aTile[count];
								dTile[counter] += 1;
								Base[counter] = false;
								if(dTile[counter] > 7){
									dTile[counter] = 7;
								}								cTile[counter] = cTile[count];
								rTile[counter] = rTile[count];
								cuTile[counter] = cuTile[count];
								countryName[counter] = countryName[count];
								countryAge[counter] = countryAge[count];
								

						}else 
						if(t == 2 ){
						int t2 = 0;
						int allyChance =  6500;
						
						if(iTile[counter] == iTile[count]){
							 allyChance  -= 1000;
						}
						if(rTile[counter] == rTile[count]){
							allyChance -= 4000;
						}
						if(cuTile[counter] == cuTile[count]){
							allyChance -= 2000;
						}
						
						if (iTile[counter] == iTile[count]) {
							allyChance = 5;
						}
						int t3 = rand.nextInt(18000);
						if (iTile[counter] != iTile[count] && rTile[counter] != rTile[count]) {
							t3 = rand.nextInt(3);
						}
						t2 = rand.nextInt(allyChance);
						if(t2 == 1 && aTile[counter] != aTile[count] ){
							
							aTile[count].setTank(aTile[count].getTank() + aTile[counter].getTank());
							aTile[count].setBoats(aTile[count].getBoats() + aTile[counter].getBoats());
							aTile[count].setNukes(aTile[count].getNukes() + aTile[counter].getNukes());
						for(int counting = 0;counting<tottiles;counting++){
							if(cTile[counting] == cTile[counter]){
								
								
								aTile[counting] = aTile[count];
								

							}
						}
						
					}else if(aTile[count] == aTile[counter]){
						if(t3 == 1){
						Alliance a6 = new Alliance();
						a6.setAc(new Color(rand.nextInt(254) + 1, rand.nextInt(254) + 1, rand.nextInt(254) + 1));
						for(int countz = 0;countz<tottiles;countz++){
							if(cTile[countz] == cTile[counter]){
								aTile[countz] = a6;
							}
						
						}
					}else
						if(t3 == 2){
						
							Alliance a6 = new Alliance();
							a6.setAc(new Color(rand.nextInt(254) + 1, rand.nextInt(254) + 1, rand.nextInt(254) + 1));
							for(int countz = 0;countz<tottiles;countz++){
								if(cTile[countz] == cTile[counter]){
									eTile[countz] = a6;

								}
							}
							for(int countz = 0;countz<tottiles;countz++){
								if(cTile[countz] == cTile[count]){
									eTile[countz] = a6;
								}
							}
							
							}
						
						}
						
					}
					}
				}
				}
			
				}
			
				//aTile[counter].setTank(0);
			}
		
	
		}
		}catch(Exception e){
			
		}
		
	}
	
	public void boats(){
		if(land >= maxLand && Fact.paused == false){
			for(int counter = 0;counter<tottiles;counter++){
				for(int count = 0;count<tottiles;count++){
					
					if(tileType[counter] == 0 && tileType[count] == 1 && aTile[counter] != aTile[count] && cTile[count] != Color.GREEN){
					if(xtile[counter] > xtile[count] - ts *2 && xtile[counter] < xtile[count] +  ts *2 && ytile[counter] > ytile[count] - ts * 2 && ytile[counter] < ytile[count] +  ts *2 ){
					int chance = 400;
					if(Base[counter] == false){
						chance *= 100;
					}
					int t = rand.nextInt(chance);
				
						if(Map.aTile[count] != null){
						if(t == 1 && Map.aTile[count].getBoats() > 0 ){
						Map.aTile[count].setBoats(Map.aTile[count].getBoats() - 1);
							boated[counter] = true;
							if(nuclear[count] == true){
								nuclear[counter] = true;
							}
							cTile[counter] = cTile[count];
							countryName[counter] = countryName[count];
							countryAge[counter] = countryAge[count];

							iTile[counter] = iTile[count];
							rTile[counter] = rTile[count];
							cuTile[counter] = cuTile[count];
							aTile[counter] = aTile[count];
						}
					}
					}
					}
				}
				}
					
			}
	}
	public void moveBoats(){
		for(int counter = 0;counter<tottiles;counter++){
			if(boated[counter] == false && tileType[counter] == 0){
				iTile[counter] = null;
				rTile[counter] = null;
				cuTile[counter] = null;
				countryName[counter] = null;
				countryAge[counter] = 0;
			}
		}
		if(land >= maxLand && Fact.paused == false){
			for(int counter = 0;counter<tottiles;counter++){
				for(int count = 0;count<tottiles;count++){
					
					if(tileType[count] == 0 && boated[count] == true && aTile[counter] != aTile[count]){
					if(xtile[counter] > xtile[count] - ts *2 && xtile[counter] < xtile[count] +  ts *2 && ytile[counter] > ytile[count] - ts * 2 && ytile[counter] < ytile[count] +  ts *2 ){
					

						int t = rand.nextInt(12);
						
						if(t == 1){
				
							if(tileType[counter] == 0){
								boated[count] = false;
								if(nuclear[count] == true){
									nuclear[counter] =true;
									nuclear[count] = false;

								}
								boated[counter] = true;
								cTile[counter] = cTile[count];

								iTile[counter] =iTile[count];
								rTile[counter] = rTile[count];
								cuTile[counter] = cuTile[count];
								countryName[counter] = countryName[count];
								countryAge[counter] = countryAge[count];

								iTile[count] = null;
								cTile[count] = null;
								rTile[count] = null;
								cuTile[count] = null;
								aTile[counter] = aTile[count];
								aTile[counter].setTank(aTile[count].getTank());
								aTile[count] = null;
							
								//cTile[count] = Color.BLACK;
							}else if(tileType[counter] == 1 && cTile[counter] != cTile[count]){
								boated[count] = false;
						
								
								if(nuclear[count] == true){
								nuclear[counter] =true;
								nuclear[count] = false;

								}
								iTile[counter] = iTile[count];
								cTile[counter] = cTile[count];
								Base[counter] = false;

							

								rTile[counter] = rTile[count];
								cuTile[counter] = cuTile[count];
								countryName[counter] = countryName[count];
								countryAge[counter] = countryAge[count];

								aTile[counter] = aTile[count];

								aTile[counter].setTank(aTile[count].getTank());
								aTile[count].setTank(0);

								aTile[count] = null;
								cuTile[count] = null;
								cTile[count] = null;
								iTile[count] = null;
							}
							
						
							
						}
					}
					}
					
				}
				}
					
			}
	}
	public void makeBase(){
		for(int counter = 0;counter<tottiles;counter++){
			if(tileType[counter] == 1){
			int t = rand.nextInt(19000);
			if(t == 1){
			//Base[counter] = true;
			}
			}
			
		}
	}
	public void makeNuke(){
		for(int counter = 0;counter<tottiles;counter++){
			if(Fact.paused == false){
			if(tileType[counter] == 1){
			
			int t = rand.nextInt(gainNuke);
			if(t == 1){
				for(int count=0;count<tottiles;count++){
					if(cTile[count] == cTile[counter]){
						nuclear[count] = true;
					}
				}
				
			System.out.println("nukez");
			}
			if(nuclear[counter] == true){
			for(int count=0;count<tottiles;count++){
				if(cTile[count] == cTile[counter]){
					nuclear[count] = true;
				}
			}
			}
			}
			
		}
		}
	}
	public void develope(){
		if(Fact.paused == false){
		for(int counter = 0;counter<tottiles;counter++){
			if(aTile[counter] != null){
				int t = rand.nextInt(500);
				int t1 = rand.nextInt(2500);
				if(t == 1 && dTile[counter] > 2){
					dTile[counter]-= 1;
				}
				if(t1 == 1){
					Base[counter] = true;
				}
			}
		}
		}
	}
	public void makeTroops(){
		if(Fact.paused == false){
		for(int counter = 0;counter<tottiles;counter++){
			if(aTile[counter] != null){
				int t = rand.nextInt(10/dTile[counter]);
				
				if(t == 1 && Map.cTile[counter] != Color.GREEN && Map.aTile[counter] != null && Base[counter] == true){
					Map.aTile[counter].setTank(Map.aTile[counter].getTank()+1);
				}
				int xi = rand.nextInt(1000000/dTile[counter]);
				if(xi == 1 && Map.cTile[counter] != Color.GREEN && Map.aTile[counter] != null ){
					Map.aTile[counter].setTank(Map.aTile[counter].getTank()+1);
				}
				int t2 = rand.nextInt(30/dTile[counter]);
				if(t == 2 && t2 == 1  && Map.cTile[counter] != Color.GREEN  && Map.aTile[counter] != null){
					Map.aTile[counter].setBoats(Map.aTile[counter].getBoats()+1);

				}
				int t3 = rand.nextInt(30/dTile[counter]);
				//if(Fact.year > 10 &&t == 2 && t3 == 1  && Map.cTile[counter] != Color.GREEN  && Map.aTile[counter] != null && Base[counter] == true){
					//Map.aTile[counter].setNukes(Map.aTile[counter].getNukes()+3);

				//}
				int aNum = 0;
				for(int cz = 0;cz<Map.tottiles;cz++){
					
					if(Map.aTile[cz] == Map.aTile[counter] && Map.tileType[cz] == 1 && aTile[cz] != null){
						aNum++;
					}
				}
				for(int count = 0;count<Map.tottiles;count++){
					if(aTile[count] != null){
					if(Map.aTile[count].getTank() > aNum)	{
						Map.aTile[count].setTank(aNum);
					}
				}
					}
			}
		}
		}
	}
	public void makePort(){
		if(land >= maxLand && ported == false){
		for(int counter = 0;counter<tottiles;counter++){
			for(int count = 0;count<tottiles;count++){
				if(ported == false){
				
				if(tileType[counter] == 1 && tileType[count] == 0){
				if(xtile[counter] > xtile[count] - ts *2 && xtile[counter] < xtile[count] +  ts *2 && ytile[counter] > ytile[count] - ts * 2 && ytile[counter] < ytile[count] +  ts *2 ){
					int t = rand.nextInt(35);
					if(Menu.arch == true){
						t = rand.nextInt(15);
					}
					if(t == 1){
						ports++;
						Base[counter] = true;
					}
				}
				}
				}
			}
			}
		ported = true;
				
		}
	}
	public void Rebel(){
		if(land >= maxLand && Menu.perp == true && Fact.paused == false ){
		for(int counter = 0;counter<tottiles;counter++){
			if(cTile[counter] != Color.GREEN){
			int r = rand.nextInt(tottiles * rebChance);
			if(r == 1){
				//System.out.println("Rebel");
				for(int count = 0;count<tottiles;count++){
					int t = rand.nextInt(7);
					if(cTile[count] == cTile[counter] && t <=3){
						cTile[count] = new Color(rand.nextInt(255),rand.nextInt(255),rand.nextInt(255));
						Alliance a2 = new Alliance();
						a2.setAc(cTile[count]);
						int ide = rand.nextInt(15);
						countryName[count] = randomName();
						nuclear[count] = false;
						capital[count] = true;
						dTile[counter] += 1;
						Base[counter] = false;
						if(dTile[counter] > 7){
							dTile[counter] = 7;
						}						
						countryAge[count] = 0;
						int re = rand.nextInt(8);
						if(re == 1){
							Religion ri = new Religion(randomName());
							ri.setC(new Color(rand.nextInt(255),rand.nextInt(255),rand.nextInt(255)));
							knownR.add(ri);
							rTile[count] = ri;
						}else{
							for(int co = 0;co<tottiles;co++){
								if(tileType[co] == 1){
									int pickzzr = rand.nextInt(200);
									if(pickzzr == 1){
										rTile[count] = rTile[co];
									}
								}
							}
						}
						int cut = rand.nextInt(20);
						if(cut == 1){
							Culture ri = new Culture(randomName());
							ri.setC(new Color(rand.nextInt(255),rand.nextInt(255),rand.nextInt(255)));
							knowC.add(ri);
							cuTile[count] = ri;
						}else{
							for(int co = 0;co<tottiles;co++){
								if(tileType[co] == 1){
									int pickzzr = rand.nextInt(400);
									if(pickzzr == 1){
										cuTile[count] = cuTile[co];
									}
								}
							}
						}
					if(ide == 1){
						int sway = rand.nextInt(100);
						if (sway < 20) {
							Ideology itz = new Ideology(randomName());
							itz.setC(new Color(rand.nextInt(255),rand.nextInt(255),rand.nextInt(255)));
							knownI.add(itz);
							iTile[count] = itz;
						}
						
						
					}else{
						for(int co = 0;co<tottiles;co++){
							if(tileType[co] == 1){
								int pickzz = rand.nextInt(tottiles);
								if(pickzz == 1){
									iTile[count] = iTile[co];
								}
							}
						}
					}
						a2.getNations().add(cTile[count]);
						a2.setTank(5);
						aTile[count] = a2;
						
					}
				}
			}
			}
		}
	}
	}
	public void reset(Graphics g){
		
		g.setColor(Color.RED);
		g.fillRect(650, 50, 40, 25);
		g.setColor(Color.BLACK);
		g.drawString("Reset", 655, 60);
		if(Fact.xM > 650 && Fact.xM < 690){
			if(Fact.yM > 50 && Fact.yM < 75){
				Fact.yM += 100;
				x = 50;
				y = 50;
				civFounded = false;
				Fact.year = 0;
				for(int counter = 0;counter<tottiles;counter++){
					Base[counter] = false;
					tileType[counter] = 0;
					boated[counter] = false;
					dTile[counter] = 7;
					Ideology itz = new Ideology(randomName());
					itz.setC(new Color(rand.nextInt(255),rand.nextInt(255),rand.nextInt(255)));
					knownI.add(itz);
					
					Religion ri = new Religion(randomName());
					ri.setC(new Color(rand.nextInt(255),rand.nextInt(255),rand.nextInt(255)));
					knownR.add(ri);
					
					Culture cu = new Culture(randomName());
					cu.setC(new Color(rand.nextInt(255),rand.nextInt(255),rand.nextInt(255)));
					knowC.add(cu);
					cuTile[counter] = cu;
					rTile[counter] = ri;
					iTile[counter] = itz;
					nuclear[counter]= false;
				}
				ported = false;
				land = 0;
				started = false;
			}
		}
		
	}
	public void FactInfo(Graphics g){
		int cNum = 0;
		int aNum = 0;
		int aNukes =0;
		int fact = 0;
		int allyFact = 0;
		int fb = 0;
		int fTiles = 0;
		int dTiles = 0;
		int db = 0;
		int tTiles = 0;
		int tb = 0;
		
		int cuNum = 0;
		int cuB = 0;
		int reNum = 0;
		int reB = 0;
		int mNum =0;
		int mB = 0;
		int mTiles = 0;
		
		int coNum = 0;
		int cB = 0;
		int coTiles = 0;
		
		int ideoT = 0;
		int ideoB = 0;
		for(int counter = 0;counter<Map.tottiles;counter++){
			if(Fact.paused == false){
			countryAge[counter]++;
			}
		
		}

		if(Fact.yM > 600 && Fact.yM < 620){
			if(Fact.xM > 30 && Fact.xM < 50){
				Fact.selectedNation = 1;
			}else if(Fact.xM > 50 && Fact.xM < 70){
				Fact.selectedNation = 2;

			}else if(Fact.xM > 70 && Fact.xM < 90){
				Fact.selectedNation = 3;

			}else if(Fact.xM > 90 && Fact.xM < 110){
				Fact.selectedNation = 4;

			}else if(Fact.xM > 110 && Fact.xM < 120){
				Fact.selectedNation = 5;

			}else if(Fact.xM > 130 && Fact.xM < 150){
				Fact.selectedNation = 6;
			}
			else if(Fact.xM > 150 && Fact.xM < 170){
				Fact.selectedNation = 7;
			}
			if(Fact.xM > 200 && Fact.xM < 220){
				Fact.selectedFaction = 0;
			}else if(Fact.xM > 220 && Fact.xM < 240){
				Fact.selectedFaction = 1;
			}else if(Fact.xM > 240 && Fact.xM < 260){
				Fact.selectedFaction = 2;
			}
		}else if(Fact.yM > 622 && Fact.yM < 642){
			if(Fact.xM > 30 && Fact.xM < 50){
				Fact.selectedF = 1;
			}else if(Fact.xM > 50 && Fact.xM < 70){
				Fact.selectedF = 2;

			}else if(Fact.xM > 70 && Fact.xM < 90){
				Fact.selectedF = 3;

			}else if(Fact.xM > 90 && Fact.xM < 110){
				Fact.selectedF = 4;

			}else if(Fact.xM > 110 && Fact.xM < 120){
				Fact.selectedF = 5;

			}else if(Fact.xM > 130 && Fact.xM < 150){
				Fact.selectedF = 6;
			}
			else if(Fact.xM > 150 && Fact.xM < 170){
				Fact.selectedF = 7;
			}
		}
		
		
		for(int counter=0;counter<Map.tottiles;counter++){
			g.setColor(Color.RED);
			if(Fact.yM > Map.ytile[counter] && Fact.yM < Map.ytile[counter] + 10){
			if(Fact.xM > Map.xtile[counter] && Fact.xM < Map.xtile[counter] + 10){
				if(Fact.edit == false){
				if(aTile[counter] != null){
					//ideoSelect = Map.iTile[counter].getName()	;
				g.drawString("Troops : " + Integer.toString(Map.aTile[counter].getTank()), 40, 530);
				g.drawString("Region Name : " + Map.countyName[counter], 40, 550);
				if(nuclear[counter] == true){
					g.drawString("Nuclear : True" , 40, 595);

				}else{
					g.drawString("Nuclear : False", 40, 595);

				}
				g.drawString("Country Namae : " + Map.countryName[counter], 40, 565);
				g.drawString("Country Age : " + Integer.toString(Map.countryAge[counter]), 240, 550);

				g.drawString("Ideology : " + iTile[counter].getName(), 40, 580);
				g.drawString("Religion : " + rTile[counter].getName(), 40, 610);
				
				String dev = Integer.toString(dTile[counter]);
				g.drawString("Tile Development : " + dev, 40, 630);

				
				for(int cz = 0;cz<Map.tottiles;cz++){
					if(tileType[cz] == 1){
						if(iTile[counter] == iTile[cz]){
							ideoT++;
							if(Base[cz] == true){
								ideoB++;
							}
						}
						}
					if(Map.cTile[cz] == Map.cTile[counter] && Map.tileType[cz] == 1){
						cNum++;
						if(Map.Base[cz] == true){
							fact++;
						}
					}
					if(Map.aTile[cz] == Map.aTile[counter] && Map.tileType[cz] == 1){
						aNum++;
						if(Map.Base[cz] == true){
							allyFact++;
						}
					}
					
					if(Map.cuTile[cz] == Map.cuTile[counter] && Map.tileType[cz] == 1){
						cuNum++;
						if(Map.Base[cz] == true){
							cuB++;
						}
					}
					if(Map.rTile[cz] == Map.rTile[counter] && Map.tileType[cz] == 1){
						reNum++;
						if(Map.Base[cz] == true){
							reB++;
						}
					}
				}
			
				g.drawString("Color Tiles : " + Integer.toString(cNum), 240, 530);
				g.drawString("Alliance : " + Integer.toString(aNum), 340, 530);
				
				g.drawString("Ideology Tiles : " + Integer.toString(ideoT), 400, 600);
				g.drawString("Ideology Factories : " + Integer.toString(ideoB), 540, 600);
				
				g.drawString("Religion Tiles : " + Integer.toString(reNum), 400, 615);
				g.drawString("Religion Factories : " + Integer.toString(reB), 540, 615);
				
				g.drawString("Culture Tiles : " + Integer.toString(cuNum), 400, 585);
				g.drawString("Culture Factories : " + Integer.toString(cuB), 540, 585);
				
				g.drawString("Factories : " + Integer.toString(fact), 440, 530);
				g.drawString("Alliance Factories : " + Integer.toString(allyFact), 540, 530);

			}
				}else{
					//0 -White
					//1 -Green
					//2 -Red
					//3 -Magenta
					//4 -Blue
					//5 -Orange
					
					//0 -Red
					//1 -Blue
					//2 -Orange
					Alliance a1 = new Alliance();
					a1.setAc(Color.WHITE);
					Alliance a2 = new Alliance();
					a2.setAc(Color.YELLOW);
					Alliance a3 = new Alliance();
					a3.setAc(Color.RED);
					Alliance a4 = new Alliance();
					a4.setAc(Color.MAGENTA);
					Alliance a5 = new Alliance();
					a5.setAc(Color.BLUE);
					Alliance a6 = new Alliance();
					a6.setAc(Color.ORANGE);
					Alliance a7 = new Alliance();
					a6.setAc(Color.LIGHT_GRAY);
					if(Fact.selectedNation == 1){
						
						cTile[counter] = Color.WHITE;
						
						
					}else if(Fact.selectedNation == 2){
						cTile[counter] = Color.YELLOW;
					}else if(Fact.selectedNation == 3){
						cTile[counter] = Color.RED;
					
					}else if(Fact.selectedNation == 4){
						cTile[counter] = Color.MAGENTA;
					}else if(Fact.selectedNation == 5){
						cTile[counter] = Color.BLUE;
					}else if(Fact.selectedNation == 6){
						cTile[counter] = Color.ORANGE;
					}
					else if(Fact.selectedNation == 7){
						cTile[counter] = Color.LIGHT_GRAY;
					}
					
					if(Fact.selectedF == 1){
						aTile[counter] = a1;
					}else if(Fact.selectedF == 2){
						aTile[counter] = a2;
					}else if(Fact.selectedF == 3){
						aTile[counter] = a3;
					}else if(Fact.selectedF == 4){
						aTile[counter] = a4;
					}else if(Fact.selectedF == 5){
						aTile[counter] = a5;
					}else if(Fact.selectedF == 6){
						aTile[counter] = a6;
					}else if(Fact.selectedF == 7){
						aTile[counter] = a7;
					}
					
					if(Fact.selectedFaction == 0){
						iTile[counter] = facism;
					}else if(Fact.selectedFaction == 1){
						iTile[counter] = democracy;
					}else if(Fact.selectedFaction == 2){
						iTile[counter] = theocracy;
					}
				}
}
			}
		}
	}
}
