package Pack;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Rectangle;

public class Menu {
    public static boolean gameStarted = false;
    public static boolean arch = false;
    public static boolean standard = false;
    public static boolean perp = false;
    public static boolean large = false;
    public static boolean advanced = false;

    private Rectangle[] buttons;

    public Menu() {
        buttons = new Rectangle[5];
        buttons[0] = new Rectangle(50, 50, 600, 50);
        buttons[1] = new Rectangle(50, 150, 600, 50);
        buttons[2] = new Rectangle(50, 250, 600, 50);
        buttons[3] = new Rectangle(50, 350, 600, 50);
        buttons[4] = new Rectangle(50, 450, 600, 50);
    }

    public void showMenu(Graphics g) {
        g.setColor(Color.WHITE);
        for (Rectangle button : buttons) {
            g.fillRoundRect(button.x, button.y, button.width, button.height, 20, 20);
        }
        g.setColor(Color.BLACK);
        g.setFont(new Font("Arial", Font.BOLD, 20));
        drawButton(g, buttons[0], "Archipelago (select to start simulation)", arch);
        drawButton(g, buttons[1], "Continents (select to start simulation)", standard);
        drawButton(g, buttons[2], "Perpetual War", perp);
        drawButton(g, buttons[3], "Winnable War", !perp);
        drawButton(g, buttons[4], "Advanced Options", advanced);
    }

    private void drawButton(Graphics g, Rectangle button, String label, boolean selected) {
        if (selected) {
            g.setColor(Color.RED);
        } else {
            g.setColor(Color.WHITE);
        }
        g.fillRoundRect(button.x, button.y, button.width, button.height, 20, 20);
        g.setColor(Color.BLACK);
        g.drawString(label, button.x + 20, button.y + 30);
    }

    public void click() {
        if (Fact.xM > 50 && Fact.xM < 650) {
            if (Fact.yM > 50 && Fact.yM < 100) {
                standard = false;
                arch = true;
                gameStarted = true;
            } else if (Fact.yM > 150 && Fact.yM < 200) {
                standard = true;
                arch = false;
                gameStarted = true;
            } else if (Fact.yM > 250 && Fact.yM < 300) {
                perp = true;
            } else if (Fact.yM > 350 && Fact.yM < 400) {
                perp = false;
            } else if (Fact.yM > 450 && Fact.yM < 500) {
                advanced = true;
            }
        }
    }
}
