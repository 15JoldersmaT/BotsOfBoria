package Pack;

public class Religion extends Ideology {

	public Religion(String Name) {
		super(Name);
		// TODO Auto-generated constructor stub
	}
	private String name;
	private int followers;
	private boolean violent;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getFollowers() {
		return followers;
	}
	public void setFollowers(int followers) {
		this.followers = followers;
	}
	public boolean isViolent() {
		return violent;
	}
	public void setViolent(boolean violent) {
		this.violent = violent;
	}
}
