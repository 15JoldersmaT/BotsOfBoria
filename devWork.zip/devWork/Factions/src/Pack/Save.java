package Pack;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Random;

public class Save {
	
	Random rand = new Random();
	public Save(){
		
	}
	
	public void makeSave(){
		int t = Fact.numSave;
		File dirz = new File("C:\\Warz\\Type");
		File dirz2 = new File("C:\\Warz\\Color");
		File dirz3 = new File("C:\\Warz\\Boat");



		File dir = new File("C:\\Warz\\Type\\" + Integer.toString(t)+"\\" );
		File dirw = new File("C:\\Warz\\Color\\" + Integer.toString(t)+"\\" );
		File dirzRed = new File("C:\\Warz\\Color\\" + Integer.toString(t) + "\\Red");
		File dirzGreen = new File("C:\\Warz\\Color\\"+ Integer.toString(t) + "\\Green\\");
		File dirzBlue = new File("C:\\Warz\\Color\\"+ Integer.toString(t) + "\\Blue\\");
		File dirzBoat = new File("C:\\Warz\\Boat\\"+ Integer.toString(t) + "\\");



		

		dirz.mkdir();
		dirz3.mkdir();
		dirw.mkdir();
		dirz2.mkdir();
		dirzRed.mkdir();
		dirzGreen.mkdir();
		dirzBlue.mkdir();
		dir.mkdir();
		dirzBoat.mkdir();
	
		
		for(int counter = 0;counter<Map.tottiles;counter++){
			try {
				
				PrintWriter fw = new PrintWriter("C:\\Warz\\Type\\"+Integer.toString(Fact.numSave)+"\\"+counter+ ".txt");
				//PrintWriter fw4 = new PrintWriter("C:\\Warz\\Boat\\"+Integer.toString(Fact.numSave)+"\\"+counter+ ".txt");


				//PrintWriter fw1 = new PrintWriter("C:\\Warz\\Color\\"+Integer.toString(Fact.numSave)+ "\\Red\\" +counter+ ".txt");
				//PrintWriter fw2 = new PrintWriter("C:\\Warz\\Color\\"+Integer.toString(Fact.numSave)+ "\\Green\\" +counter+ ".txt");
				//PrintWriter fw3 = new PrintWriter("C:\\Warz\\Color\\"+Integer.toString(Fact.numSave)+ "\\Blue\\" +counter+ ".txt");


				//PrintWriter fw2 = new PrintWriter("C:\\Warz\\Color\\"+Integer.toString(Fact.numSave)+"Red\\"+counter+ ".txt");



				int t1 = Map.xtile[counter];
				int t2 = Map.tileType[counter];
				System.out.println(t2);
			
				if(t2 == 0){
				fw.write("0");
				}else if(t2 == 1){
			    fw.write("1");
				}
				if(Map.boated[counter] == true){
					//fw4.write("B");
				}
				if(Map.tileType[counter] == 1){
				int red = Map.cTile[counter].getRed();
				int green = Map.cTile[counter].getGreen();
				int blue = Map.cTile[counter].getBlue();

			
				//fw1.write(Integer.toString(Map.cTile[counter].getRed()));
				//fw2.write(Integer.toString(Map.cTile[counter].getGreen()));
				//fw3.write(Integer.toString(Map.cTile[counter].getBlue()));
				}else{
					//fw1.write(Integer.toString(55));
					//fw2.write(Integer.toString(55));
					//fw3.write(Integer.toString(55));
				}
			
		
				
				//fw2.close();
				fw.close();
				///fw1.close();
				//fw2.close();
				//fw3.close();
				//fw4.close();
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
}
