package pack;

public class Admiral extends Ship{
	
	
	
	public Admiral(){
		this.setMass(5);
	}
	
	

}