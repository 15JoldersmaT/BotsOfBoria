package pack;

import java.awt.Color;

public class Faction {

	private Color c;
	
	public Faction(){
		
	}
	public Color getC() {
		return c;
	}
	public void setC(Color c) {
		this.c = c;
	}
	
}