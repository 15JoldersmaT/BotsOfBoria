package pack;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JApplet;
import javax.swing.JFrame;

public class Game extends JFrame implements KeyListener{

	Graphics dbg;
	Image db;
	Dimension d = new Dimension(800,600);
	State s = new State();
	
	public void paint(Graphics g){
		db = createImage(d.width, d.height);
		dbg = db.getGraphics();
		paintComponent(dbg);
		g.drawImage(db, 0, 0, null);
	}
	
	public void paintComponent(Graphics g){
		s.showUniverse(dbg);
	}
	public void gameLoop(){
		while(1==1){
			s.bigBang();
			s.createShips();
			s.moveShips();
			s.checkPlanetFaction();
			s.checkShipCollision();
			s.starDie();
			s.moveDust();
		//	s.nova();
			repaint();
		
			Thread t = new Thread();
			try {
				t.sleep(1);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public Game(){
		this.setBackground(Color.BLACK);
		this.setSize(d);
		this.addKeyListener(this);
		this.setVisible(true);
		this.setResizable(false);
		this.setTitle("The Very Small Bang");
		gameLoop();
	}
	public void start(){
		
	}
	public void run(){
		repaint();
	}

	public void stop(){
		
	}
	public void destroy(){
		
	}
	
	public static void main(String[] args) {
		
		new Game();
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_A){
			for(int counter = 0;counter<State.universe.size();counter++){
				State.universe.get(counter).moveLeft();
			}
			for(int counter = 0;counter<State.universeB.size();counter++){
				State.universeB.get(counter).moveLeft();
			}
			for(int counter = 0;counter<State.universeS.size();counter++){
				State.universeS.get(counter).moveLeft();
			}
		}
		if(e.getKeyCode() == KeyEvent.VK_D){
			for(int counter = 0;counter<State.universe.size();counter++){
				State.universe.get(counter).moveRight();

			}
			for(int counter = 0;counter<State.universeB.size();counter++){
				State.universeB.get(counter).moveRight();
			}
			for(int counter = 0;counter<State.universeS.size();counter++){
				State.universeS.get(counter).moveRight();
			}
		}
		if(e.getKeyCode() == KeyEvent.VK_S){
			for(int counter = 0;counter<State.universe.size();counter++){
				State.universe.get(counter).moveUp();
			}
			for(int counter = 0;counter<State.universeB.size();counter++){
				State.universeB.get(counter).moveUp();
			}
			for(int counter = 0;counter<State.universeS.size();counter++){
				State.universeS.get(counter).moveUp();
			}
		}
		if(e.getKeyCode() == KeyEvent.VK_W){
			for(int counter = 0;counter<State.universe.size();counter++){
				State.universe.get(counter).moveDown();
			}
			for(int counter = 0;counter<State.universeB.size();counter++){
				State.universeB.get(counter).moveDown();
			}
			for(int counter = 0;counter<State.universeS.size();counter++){
				State.universeS.get(counter).moveDown();
			}
		}
		
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}