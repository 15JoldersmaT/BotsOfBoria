package pack;

public class Load {

}