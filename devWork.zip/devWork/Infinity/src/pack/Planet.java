package pack;

import java.awt.Color;
import java.awt.Graphics;

public class Planet extends Dust{

	private boolean life;
	private int age;
	private boolean coreAlive;
	private Faction f;
	
	public Planet(){
		
	}
	
	public void checkLife(){
		
	}

	public boolean getLife() {
		return life;
	}

	public void moveLeft(){
		this.setX(this.getX() + 10);
	}
	public void moveRight(){
		this.setX(this.getX() - 10);

	}
	public void moveUp(){
		this.setY(this.getY() - 10);

	}
	public void moveDown(){
		this.setY(this.getY() + 10);

	}
	public void setLife(boolean life) {
		this.life = life;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public boolean isCoreAlive() {
		return coreAlive;
	}

	public void setCoreAlive(boolean coreAlive) {
		this.coreAlive = coreAlive;
	}
	public void show(Graphics g){
		g.setColor(this.getC());
		g.fillOval(this.getX(), this.getY(), this.getMass(), this.getMass());
	}
	public void nova(){
		for(int counter = 0;counter<100;counter++){
			starBit sb = new starBit();
			
			
		}
	}
	public void setColor(){
		f.getC();
	}

	public Color getC() {
		return f.getC();
	}

	public void setC() {
	
	}

	public Faction getF() {
		return f;
	}

	public void setF(Faction f) {
		this.f = f;
	}
}