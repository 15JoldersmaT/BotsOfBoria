package pack;

import java.awt.Graphics;
import java.util.Random;

public class Ship extends Dust {

	private Faction f;
	private int age;
	private int maxAge;
	public Ship(){
	Random rand = new Random();
	setMaxAge(rand.nextInt(1000) + 500);
	}

	public Faction getF() {
		return f;
	}

	public void setF(Faction f) {
		this.f = f;
	}
	public void show(Graphics g){
		
		g.setColor(f.getC());
		g.fillOval(this.getX(), this.getY(), this.getMass(), this.getMass());
	}
	
	public void moveLeft(){
		this.setX(this.getX() + 20);
	}
	public void moveRight(){
		this.setX(this.getX() - 20);

	}
	public void moveUp(){
		this.setY(this.getY() - 20);

	}
	public void moveDown(){
		this.setY(this.getY() + 20);

	}
	public void move(){
		age++;
		
		Random rand = new Random();
		int t = rand.nextInt(5);
		if(t == 1){
		this.setX(this.getX() + 2);
		if(this.getX() > 800){
			this.setX(0);
		}
		}
		if(t == 2){
		this.setX(this.getX() - 2);	
		if(this.getX() < 0){
			this.setX(798);
		}
		}
		if(t == 3){
		this.setY(this.getY() - 2);	
		if(this.getY() > 598){
			this.setY(0);
		}
		}
		if(t == 4){
		this.setY(this.getY() + 2);	
		if(this.getY() < 0){
			this.setY(598);
		}
		}
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getMaxAge() {
		return maxAge;
	}

	public void setMaxAge(int maxAge) {
		this.maxAge = maxAge;
	}
	
	
}