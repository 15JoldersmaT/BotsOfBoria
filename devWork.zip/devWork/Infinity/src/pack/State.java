package pack;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Random;

public class State {
	
	public static  ArrayList<Planet> universe = new ArrayList<Planet>();
	public static ArrayList<Faction> universeF = new ArrayList<Faction>();
	public static ArrayList<starBit> universeB = new ArrayList<starBit>();

	static ArrayList<Ship> universeS = new ArrayList<Ship>();
	
	public static int dust = 100;
	public static int totShips = 0;
	public static int maxShips = 10;
	public static int maxBits = 2000;
	public static int bits = 0;
	Random rand = new Random();
	public static boolean started = false;

	public State(){
		
	}
	
	public void bigBang(){
		if(started == false){
		for(int counter = 0;counter<=dust;counter++){
			int xing = rand.nextInt(50) + 350;
			int ying = rand.nextInt(50) + 350;
			//Faction f = new Faction();
			//f.setC(new Color(rand.nextInt(255), rand.nextInt(255), rand.nextInt(255)));
			//Planet p = new Planet();
			//p.setF(f);
			//p.setC();
			//p.setX(xing);
			//p.setY(ying);
			//p.setCoreAlive(true);
			//p.setAge(0);
			//p.setMass(8);
			//universeF.add(f);
			//universe.add(p);
			starBit sb = new starBit();
			sb.setX(xing);
			sb.setY(ying);
			int idd = rand.nextInt(50);
			sb.setID(idd);
			universeB.add(sb);

			
			
		}
		started = true;
		}
	}
	public void showUniverse(Graphics g){
		for(int counter = 0;counter<universe.size();counter++){
			universe.get(counter).show(g);
		}
		for(int counter = 0;counter<universeS.size();counter++){
			universeS.get(counter).show(g);
		}
		for(int counter = 0;counter<universeB.size();counter++){
			universeB.get(counter).show(g);
		}
	}
	public void nova(){
		for(int counter =0;counter<universe.size();counter++){
			int t = rand.nextInt(1000);
			if(t == 1){
				for(int count = 0;count<25;count++){
					starBit sb = new starBit();
					sb.setX(universe.get(counter).getX());
					sb.setY(universe.get(counter).getY());
					universeB.add(sb);

				}
			}
		}
	}
	public void createShips(){
		try{
			if(totShips <= maxShips){
		for(int counter = 0;counter<universe.size();counter++){
			universe.get(counter).setAge(universe.get(counter).getAge() + 1);
			int a = rand.nextInt(30);
			
			int t = rand.nextInt(10);
			if(t == 1){
			Ship s = new Ship();
			if(totShips <= maxShips){
			s.setF(universe.get(counter).getF());
			s.setX(universe.get(counter).getX());
			s.setY(universe.get(counter).getY());
			s.setMass(2);
			totShips++;
			universeS.add(s);
			}
			}
			 if(a == 1){
				//System.out.println("Ad");
				Admiral a1 = new Admiral();
				a1.setF(universe.get(counter).getF());
				a1.setX(universe.get(counter).getX());
				a1.setY(universe.get(counter).getY());
				a1.setMass(4);
				if(totShips <= maxShips){

				universeS.add(a1);
				totShips++;
				}
			}
			
		}
		if(totShips <= maxShips){

		for(int counter = 0;counter<universeS.size();counter++){
			if(universeS.get(counter).getMass() >= 4){
			
				if(totShips <= maxShips){
				int t = rand.nextInt(10);
				if(t == 1){
				Ship s = new Ship();
				
				s.setF(universeS.get(counter).getF());
				s.setX(universeS.get(counter).getX());
				s.setY(universeS.get(counter).getY());
				s.setMass(2);
				totShips++;
				universeS.add(s);
				
			}
				}
		}
		}
			}
		}
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	public void moveShips(){
		for(int counter = 0;counter<universeS.size();counter++){
			universeS.get(counter).move();
			if(universeS.get(counter).getAge() > 1000){
				//universeS.remove(counter);
			}
		}
		for(int counter = 0;counter<universeB.size();counter++){
			if(universeB.get(counter).getAge() > 10000){
				//universeB.remove(counter);
			}
		}
	}
	public void checkPlanetFaction(){
		for(int counter=0;counter<universe.size();counter++){
			for(int count=0;count<universeS.size();count++){
				if(universeS.get(count).getX() > universe.get(counter).getX() && universeS.get(count).getX() <= universe.get(counter).getX() + 8){
					if(universeS.get(count).getY() > universe.get(counter).getY() && universeS.get(count).getY() <= universe.get(counter).getY() + 8){
						universe.get(counter).setF(universeS.get(count).getF());
						totShips--;
						universeS.remove(count);
					}
				}
			}
		}
	}
	

	public void checkShipCollision(){
		for(int counter = 0;counter<universeS.size();counter++){
			for(int count = 0;count<universeS.size();count++){
				try{
				if(counter <= universeS.size() && count <= universeS.size()){
					if(counter<=universeS.size() && count<= universeS.size()){
				if(universeS.get(counter).getF() != universeS.get(count).getF()){
				if(universeS.get(count).getX() > universeS.get(counter).getX() && universeS.get(count).getX() <= universeS.get(counter).getX() + 2){
					if(universeS.get(count).getY() > universeS.get(counter).getY() && universeS.get(count).getY() <= universeS.get(counter).getY() + 2){
						totShips--;
						universeS.remove(counter);
					}
				}
				}
				}
				}
				}catch(Exception e){
					System.out.println(e.getMessage());
				
				}
			}
		}
	}
	public void moveDust(){
		try{
		for(int counter=0;counter<universeB.size();counter++){
			universeB.get(counter).move();
			universeB.get(counter).setAge(universeB.get(counter).getAge() + 1);
			for(int count = 0;count<universeS.size();count++){
				if(universeS.get(count).getX() > universeB.get(counter).getX() -2 && universeS.get(count).getX() <= universeB.get(counter).getX() + 2){
					if(universeS.get(count).getY() > universeB.get(counter).getY() - 2 && universeS.get(count).getY() <= universeB.get(counter).getY() + 2){
						totShips--;
						if(universeB.get(counter).getMass() > 1){
						universeS.remove(count);
						}
						
						universeB.remove(counter);
						
						bits -= 1;

					}
				}
					}
			for(int count = 0;count<universe.size();count++){
				if(universe.get(count).getX() > universeB.get(counter).getX() -8 && universe.get(count).getX() <= universeB.get(counter).getX() + 8){
					if(universe.get(count).getY() > universeB.get(counter).getY() - 8 && universe.get(count).getY() <= universeB.get(counter).getY() + 8){
						
					
						if(universeB.get(counter).getMass() > 2  && universe.get(count).getAge() > 35){
							if( universeB.get(counter).getAge() > 5 && universeB.get(counter).getMass() > 1 && universeB.get(counter).getAge() > 5){
						int idd = rand.nextInt(1000);
						if(bits < maxBits){
								for(int counti = 0;counti<10;counti++){
							starBit sb = new starBit();
							sb.setID(idd);
							int xC = rand.nextInt(3) - 3;
							int yC = rand.nextInt(3) - 3;

							sb.setX(universe.get(count).getX() + xC);
							sb.setY(universe.get(count).getY() + yC);
							if(bits < maxBits){
								bits++;
							universeB.add(sb);
							}

						}
						
						universe.remove(count);
						
						}
							universeB.remove(counter);
							bits--;

					}
						}
					}
				}
					}
			for(int count = 0;count<universeB.size();count++){
				if(universeB.get(count).getX() > universeB.get(counter).getX() - 5 && universeB.get(count).getX() <= universeB.get(counter).getX() + 10){
					if(universeB.get(count).getY() > universeB.get(counter).getY() - 5 && universeB.get(count).getY() <= universeB.get(counter).getY() + 10){
						
						if(universeB.get(counter).getMass() > 4 && universeB.get(counter).getID() != universeB.get(count).getID()){
							if(universeB.get(counter).getAge() > 50 && universeB.get(count).getAge() > 50){
							Faction f = new Faction();
							f.setC(new Color(rand.nextInt(255), rand.nextInt(255), rand.nextInt(255)));
							Planet p = new Planet();
							p.setF(f);
							p.setC();
							p.setX(universeB.get(counter).getX());
							p.setY(universeB.get(counter).getY());
							p.setCoreAlive(true);
							p.setAge(0);
							p.setMass(rand.nextInt(20) + 5);
							if(bits < maxBits){
								bits++;
							universe.add(p);
							
							universeF.add(f);
							universe.add(p);
						
							}
							universeB.remove(counter);
							universeB.remove(count);
							bits -= 2;

						}
					
					}
					}
				}
					}
			}
		}catch(Exception e){
			
		}
		
	}
	public void starDie(){
		for(int counter=0;counter<universe.size();counter++){
			if(counter<= universe.size()){
			int t = rand.nextInt(20000);
			if(t == 1){
				if(universe.get(counter).getMass() > 15){
					if(bits < maxBits){
						int idd = rand.nextInt(1000);
						for(int count = 0;count<1000;count++){
							starBit sb = new starBit();
							sb.setID(idd);
							int xC = rand.nextInt(6) - 6;
							int yC = rand.nextInt(6) - 6;

							sb.setX(universe.get(counter).getX() + xC);
							sb.setY(universe.get(counter).getY() + yC);
							
								bits++;
								universeB.add(sb);
							
							}

						}
					
				}
				else if(universe.get(counter).getMass() < 7 && universe.get(counter).getMass() > 4 ){

				int idd = rand.nextInt(1000);
				
					universe.get(counter).setMass(universe.get(counter).getMass() -3);
				
				
			}
				else if(universe.get(counter).getMass() > 7 && universe.get(counter).getMass() < 15){
					universe.get(counter).setMass(universe.get(counter).getMass() +  8);

			}
		}
	}
	}
	}
}