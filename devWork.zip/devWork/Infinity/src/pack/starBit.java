package pack;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class starBit extends Dust{
	
	private String direction;
	Random rand = new Random();
	private int speedRight = 2;
	private int speedLeft = 2;
	private int speedUp = 2;
	private int speedDown = 2;
	private int ID = 0;
	private int age = 0;
	private int maxAge;
	
	public starBit(){
		setMaxAge(rand.nextInt(1000) + 500);

		this.speedDown = rand.nextInt(2) + 2;
		this.speedUp = rand.nextInt(2) + 2;
		this.speedLeft = rand.nextInt(2) + 2;
		this.speedRight = rand.nextInt(2) + 2;


		this.setMass(rand.nextInt(6) + 1);
		int r = rand.nextInt(8);
	
	}

public void show(Graphics g){
	System.out.println("dust");
		g.setColor(Color.WHITE);
	g.fillOval(this.getX(), this.getY(), this.getMass(), this.getMass());
	
}
	public void move(){
		 age++;
		this.setX(this.getX() - speedLeft);
		this.setX(this.getX() + speedRight);
		
		this.setY(this.getY() - speedUp);
		this.setY(this.getY() + speedDown);
		int tt = rand.nextInt(10);
		if(tt == 1){
			this.speedDown = rand.nextInt(2) + 2;
			this.speedUp = rand.nextInt(2) + 2;
			this.speedLeft = rand.nextInt(2) + 2;
			this.speedRight = rand.nextInt(2) + 2;
		}
		if(this.getY() > 600){
			this.setY(0);
		}
		if(this.getY() < 0){
			this.setY(600);
		}
		if(this.getX() > 800){
			this.setX(0);
		}
		if(this.getX() < 0){
			this.setX(800);
		}

		
	}

	public void moveLeft(){
		this.setX(this.getX() + 20);
	}
	public void moveRight(){
		this.setX(this.getX() - 20);

	}
	public void moveUp(){
		this.setY(this.getY() - 20);

	}
	public void moveDown(){
		this.setY(this.getY() + 20);

	}
	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getMaxAge() {
		return maxAge;
	}

	public void setMaxAge(int maxAge) {
		this.maxAge = maxAge;
	}

	public int getSpeedRight() {
		return speedRight;
	}

	public void setSpeedRight(int speedRight) {
		this.speedRight = speedRight;
	}

	public int getSpeedLeft() {
		return speedLeft;
	}

	public void setSpeedLeft(int speedLeft) {
		this.speedLeft = speedLeft;
	}

	public int getSpeedDown() {
		return speedDown;
	}

	public void setSpeedDown(int speedDown) {
		this.speedDown = speedDown;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}
	
}