package pack;

import javax.swing.*;
import javax.swing.Timer;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Boria extends JPanel implements ActionListener {
    private Timer timer;
    private ExecutorService executor;
    public static List<Bot> bots;
    public static List<Food> foodItems;

    private static final int DELAY = 45; // Milliseconds between update/render calls
    private static final int CREATURE_SIZE = 50;
    private static final int MAX_CREATURES = 50;
    private static final int FOOD_RADIUS = 10;
    private static final int CREATURE_RADIUS = 30;
    private static final int INITIAL_BOTS = 3500;
    private static final int INITIAL_FOOD = 10;

    public static Universe u = new Universe();

    public static boolean big = false;
    public static boolean little = false;
    public static boolean reallyLittle = false;
    public static boolean kMode = false;
    public static boolean nMode = false;
    public static boolean sMode = false;
    public static boolean dMode = false;
    public static boolean uMode = true;

    public static boolean high = false;
    public static boolean gravityM = false;
    public static boolean col = false;
    public static boolean auto = false;
    public static int countDown = 1000;
    public static boolean emptyMode = false;
    public static Random rand = new Random();

    public static boolean gravity = false;
    public static boolean gravityC = false;

    public static int sTime = 1;
    public static boolean white;
    public static boolean weird;
    public static boolean weird2;
    public static boolean weird3;
    public static boolean weird4;
    public static boolean weird5;
    public static boolean weird6;
    public static boolean weird7;
    public static boolean weird8;
    public static boolean weird9;
    public static boolean weird10;
    public static boolean weird11;
    public static boolean weird12;
    public static boolean weird13;
    public static boolean weird14;
    public static boolean weird21;
    public static boolean weird22;
    public static boolean weird24;
    public static boolean weird25;

    private static boolean isPaused = false; // Added to keep track of pause state
    public static boolean weird15;
    public static boolean weird16;
    public static boolean weird17;
    public static boolean weird18;
    public static boolean mixedMode;

    public static Map<Color, boolean[]> colorEffects = new HashMap<>();
    private static final Random random = new Random();

    // Define colors
    private static final Color[] COLORS = {
        new Color(255, 0, 0),     // Red
        new Color(0, 255, 0),     // Green
        new Color(0, 0, 255),     // Blue
        new Color(255, 165, 0),   // Orange
        new Color(0, 255, 255),   // Cyan
        new Color(200, 55, 187),  // Purple
        new Color(215, 134, 18)   // Brown
    };

    // Initialize color effects for each color
    static {
        randomizeEffects();
    }

    public Boria() {
        setPreferredSize(new Dimension(1100, 700));
        setBackground(Color.BLACK);
        initGame();
    }

    private void initGame() {
        bots = new ArrayList<>();
        foodItems = new ArrayList<>();

        // Populate the bots list with initial creatures
        for (int i = 0; i < INITIAL_BOTS; i++) {
            bots.add(new Bot(650, 400, new Color(255, 0, 0))); // Starting all bots at the center for simplicity
        }

        // Populate the food list
        spawnFood();

        executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

        // Initialize the javax.swing.Timer
        timer = new Timer(DELAY, this);
        timer.start();
    }

    private void spawnFood() {
        for (int i = 0; i < INITIAL_FOOD; i++) {
            foodItems.add(new Food(rand.nextInt(1100), rand.nextInt(700)));
        }
    }

    private void spawnCreature(int centerX, int centerY, Color color) {
        for (int i = 0; i < CREATURE_SIZE; i++) {
            int offsetX = rand.nextInt(CREATURE_RADIUS) - CREATURE_RADIUS / 2;
            int offsetY = rand.nextInt(CREATURE_RADIUS) - CREATURE_RADIUS / 2;
            bots.add(new Bot(centerX + offsetX, centerY + offsetY, color));
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        doDrawing(g);
    }

    private void doDrawing(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.WHITE);
        g.fillRect(0, 0, 1200, 1200);
        if (!weird && !weird22 && !weird25 && !weird24 && !weird2 && !weird4 && !weird7 && !weird8 && !weird9 && !weird10 && !weird11 && !weird12 && !weird13 && !weird14 && !weird21) {
            g2d.setColor(new Color(0, 0, 0));
        } else if (weird2) {
            g2d.setColor(new Color(210, 210, 110));
        } else if (weird4) {
            g2d.setColor(new Color(209, 184, 205));
        } else if (weird8) {
            g2d.setColor(new Color(210, 169, 147));
        } else if (weird9) {
            g2d.setColor(new Color(40, 85, 204));
        } else if (weird10) {
            g2d.setColor(new Color(34, 47, 255)); // Winter theme background
        } else if (weird11) {
            g2d.setColor(new Color(255, 105, 97)); // Fire theme background
        } else if (weird12) {
            g2d.setColor(new Color(255, 223, 186)); // Beach Time theme background
        } else if (weird13) {
            g2d.setColor(new Color(0, 0, 200)); // Autumn theme background
        } else if (weird14) {
            g2d.setColor(new Color(0, 100, 100)); // Spring theme background
        } else if (weird21) {
            g2d.setColor(new Color(191, 215, 234)); // Spring theme background
        } else if (weird22) {
            g2d.setColor(new Color(143, 125, 20)); // Spring theme background
        } else if (weird24) {
            g2d.setColor(new Color(91, 89, 65)); // Spring theme background
        } else if (weird25) {
            g2d.setColor(new Color(105, 205, 255)); // Spring theme background
        } else {
            g2d.setColor(Color.WHITE);
        }
        g.fillRect(10, 10, 1080, 680);

        for (Bot bot : bots) {
            bot.draw(g2d);
        }

        for (Food food : foodItems) {
            food.draw(g2d);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        updateGame();
        repaint();
    }

    private void updateGame() {
        if (!isPaused) {
            countDown -= 1;
            if (auto) {
                if (countDown < 1) {
                    countDown = 500;
                    u.reset(); // Call the static reset method
                }
            }

            checkForFoodCollisions();

            // Submit bot update tasks to the executor
            for (Bot bot : bots) {
                executor.submit(bot::update);
            }
        }
    }

    private void checkForFoodCollisions() {
        List<Food> foodToRemove = new ArrayList<>();
        int currentCreatureCount = bots.size() / CREATURE_SIZE;

        for (Bot bot : bots) {
            for (Food food : foodItems) {
                if (distance(bot.getX(), bot.getY(), food.getX(), food.getY()) < FOOD_RADIUS + Bot.SIZE / 2) {
                    if (currentCreatureCount < MAX_CREATURES) {
                        // Spawn a new creature at the location of the bot
                        spawnCreature((int) bot.getX(), (int) bot.getY(), bot.getColor());
                        currentCreatureCount++;
                    }
                    foodToRemove.add(food);  // Mark food for removal after consumption
                }
            }
        }

        foodItems.removeAll(foodToRemove);  // Remove all food that was consumed
        if (foodItems.isEmpty()) {
            spawnFood();  // Replenish food if all are consumed
        }
    }

    private double distance(double x1, double y1, double x2, double y2) {
        return Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
    }

    public static void randomizeEffects() {
        for (Color color : COLORS) {
            boolean[] effects = new boolean[3];
            effects[0] = random.nextBoolean(); // Shine
            effects[1] = random.nextBoolean(); // Translucent
            effects[2] = random.nextBoolean(); // Fuzzy
            colorEffects.put(color, effects);
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Boria Simulation");
        Boria simulation = new Boria();
        frame.add(simulation);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        // Register a key listener for pause functionality
        frame.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                    isPaused = !isPaused;
                }
            }
        });
    }
}
