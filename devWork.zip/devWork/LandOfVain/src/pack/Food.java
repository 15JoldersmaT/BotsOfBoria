package pack;

import java.awt.Color;
import java.awt.Graphics2D;

public class Food {
    private int x, y;
    private static final int FOOD_RADIUS = 10;
    private static final Color FOOD_COLOR = new Color(0, 255, 0); // Always green for food

    public Food(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public void draw(Graphics2D g2d) {
        g2d.setColor(FOOD_COLOR);
        g2d.fillOval(x - FOOD_RADIUS / 2, y - FOOD_RADIUS / 2, FOOD_RADIUS, FOOD_RADIUS);
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}
