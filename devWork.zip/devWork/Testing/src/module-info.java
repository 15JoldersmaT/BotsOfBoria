
module Testing {
	requires java.desktop;
}